<?php 
session_start();
include('AmadeusService.php');
include('apphead.php');
//include('func_validate_booking.php');
function display_user_err($data=array())
{
extract($data);
$err_='<errorDetails>
<errorOrgin>'.$errorOrgin.'</errorOrgin>
<errorCode>'.$errorCode.'</errorCode>
<errorText>'.$errorText.'</errorText>
</errorDetails>';
return $err_;
}

function signout_body()
{
 return $b='<Security_SignOut xmlns="http://xml.amadeus.com/VLSSOQ_04_1_1A"> </Security_SignOut>';
}

function check_availability_A($res_Fare_InformativePricingWithoutPNR)
{
  $Fare_InformativePricingWithoutPNRReply=$res_Fare_InformativePricingWithoutPNR->Body->Fare_InformativePricingWithoutPNRReply->messageDetails->responseType;
  if($Fare_InformativePricingWithoutPNRReply=='A')
  {
    return true;
  }
  else
  {
   return false; 
  }
}



function Get_sessions_data($res_Fare_InformativePricingWithoutPNR)
{
  //debug($res_Fare_InformativePricingWithoutPNR);
  $TransactionStatusCode=$res_Fare_InformativePricingWithoutPNR->Header->Session[0]['TransactionStatusCode'];
  $session_id=$res_Fare_InformativePricingWithoutPNR->Header->Session->SessionId;
  $SequenceNumber=$res_Fare_InformativePricingWithoutPNR->Header->Session->SequenceNumber;
  $SecurityToken=$res_Fare_InformativePricingWithoutPNR->Header->Session->SecurityToken;
  $session_data['session_id']=$session_id;
  $session_data['SequenceNumber']=$SequenceNumber;
  $session_data['SecurityToken']=$SecurityToken;
  $session_data['TransactionStatusCode']=$TransactionStatusCode;
  return $session_data;
}

function body_Fare_InformativePricingWithoutPNR($pass_data,$journey)
{
  $quantity=1; 
  extract($pass_data);
  $req_Fare_InformativePricingWithoutPNR='';//$header_soap;
$req_Fare_InformativePricingWithoutPNR.='<Fare_InformativePricingWithoutPNR>';
  if($adult_config>0)
  {
  $request_soap_adult='<passengersGroup>
    <segmentRepetitionControl>
      <segmentControlDetails>
        <quantity>'.$quantity.'</quantity>
        <numberOfUnits>'.$adult_config.'</numberOfUnits>
      </segmentControlDetails>
    </segmentRepetitionControl>
    <travellersID>';
    for($adult=1;$adult<=$adult_config;$adult++)
    {
  $request_soap_adult.='<travellerDetails>
        <measurementValue>'.$adult.'</measurementValue>
      </travellerDetails>';
    }
    $request_soap_adult.='</travellersID>
      <discountPtc>
        <valueQualifier>ADT</valueQualifier>
      </discountPtc>
    </passengersGroup>';
$req_Fare_InformativePricingWithoutPNR.=$request_soap_adult;
}
if($infant_config>0)
    { 
     $quantity=$quantity+1; 
  $infant_detail='<passengersGroup>
    <segmentRepetitionControl>
      <segmentControlDetails>
        <quantity>'.$quantity.'</quantity>
        <numberOfUnits>'.$infant_config.'</numberOfUnits>
      </segmentControlDetails>
    </segmentRepetitionControl>
    <travellersID>';
    for($infant=1;$infant<=$infant_config;$infant++)
      {
      $infant_detail.='<travellerDetails>
        <measurementValue>'.$infant.'</measurementValue>
      </travellerDetails>';
      }
   $infant_detail.='</travellersID>
      <discountPtc>
        <valueQualifier>INF</valueQualifier>
        <fareDetails>
          <qualifier>766</qualifier>
        </fareDetails>
      </discountPtc>
  </passengersGroup>';
  $req_Fare_InformativePricingWithoutPNR.=$infant_detail;
}
  if($child_config>0)
 { 
  $quantity=$quantity+1; 
   $child_loop_disconnect=$adult_config + $child_config; 
  $child_details='<passengersGroup>
    <segmentRepetitionControl>
      <segmentControlDetails>
        <quantity>'.$quantity.'</quantity>
        <numberOfUnits>'.$child_config.'</numberOfUnits>
      </segmentControlDetails>
    </segmentRepetitionControl>
    <travellersID>';
    for($child=$adult;$child<=$child_loop_disconnect;$child++)
    {
  $child_details.='<travellerDetails>
        <measurementValue>'.$child.'</measurementValue>
      </travellerDetails>';
    }
      $child_details.='
    </travellersID>
      <discountPtc>
        <valueQualifier>CH</valueQualifier>
      </discountPtc>
   </passengersGroup>';
  $req_Fare_InformativePricingWithoutPNR.=$child_details;
 }
$slice_flight=search_booking_itinerary_using_ref($pass_data); //booking segment
if(empty($slice_flight))
{
echo $err_flight_ref='<errorDetails>
<errorOrgin>FRNF</errorOrgin>
<errorText>Flight Reference Not Found</errorText>
</errorDetails>';
  exit;
}
//booking segment
//echo '<pre>';
//print_r($slice_flight);
//exit;
$itemNumber=1;
$dep_details=$slice_flight->departureFlights->flightDetails;

$segment='';
$flight_indicate=0;
foreach ($dep_details as $key => $depsegment) {
$departure_date=$depsegment->flightInformation->productDateTime->dateOfDeparture;
$fromlocation=$depsegment->flightInformation->location[0]->locationId;
$tolocation=$depsegment->flightInformation->location[1]->locationId;
$marketing=$depsegment->flightInformation->companyId->marketingCarrier;
$operating=$depsegment->flightInformation->companyId->operatingCarrier;
$flightno=$depsegment->flightInformation->flightOrtrainNumber;

$bookingclass=$depsegment->cabinProduct->rbd;
$flight_indicate=$flight_indicate+1;
$segment1='<segmentGroup>
    <segmentInformation>
      <flightDate>
        <departureDate>'.$departure_date.'</departureDate>
      </flightDate>
      <boardPointDetails>
        <trueLocationId>'.$fromlocation.'</trueLocationId>
      </boardPointDetails>
      <offpointDetails>
        <trueLocationId>'.$tolocation.'</trueLocationId>
      </offpointDetails>
      <companyDetails>
        <marketingCompany>'.$marketing.'</marketingCompany>
        <operatingCompany>'.$operating.'</operatingCompany>
      </companyDetails>
      <flightIdentification>
        <flightNumber>'.$flightno.'</flightNumber>
        <bookingClass>'.$bookingclass.'</bookingClass>
      </flightIdentification>
      <flightTypeDetails>
        <flightIndicator>1</flightIndicator>
      </flightTypeDetails>
      <itemNumber>'.$itemNumber.'</itemNumber>
    </segmentInformation>
  </segmentGroup>';
$itemNumber=$itemNumber+1;
$req_Fare_InformativePricingWithoutPNR.=$segment1; 
}

if(!empty($slice_flight->returnFlights->flightDetails))
{
$ret_details=$slice_flight->returnFlights->flightDetails;
$segment='';
$flight_indicate=0;
foreach ($ret_details as $key => $depsegment) {
$departure_date=$depsegment->flightInformation->productDateTime->dateOfDeparture;
$fromlocation=$depsegment->flightInformation->location[0]->locationId;
$tolocation=$depsegment->flightInformation->location[1]->locationId;
$marketing=$depsegment->flightInformation->companyId->marketingCarrier;
$operating=$depsegment->flightInformation->companyId->operatingCarrier;
$flightno=$depsegment->flightInformation->flightOrtrainNumber;
$bookingclass=$depsegment->cabinProduct->rbd;

$flight_indicate=$flight_indicate+1;
$segment2='<segmentGroup>
    <segmentInformation>
      <flightDate>
        <departureDate>'.$departure_date.'</departureDate>
      </flightDate>
      <boardPointDetails>
        <trueLocationId>'.$fromlocation.'</trueLocationId>
      </boardPointDetails>
      <offpointDetails>
        <trueLocationId>'.$tolocation.'</trueLocationId>
      </offpointDetails>
      <companyDetails>
        <marketingCompany>'.$marketing.'</marketingCompany>
        <operatingCompany>'.$operating.'</operatingCompany>
      </companyDetails>
      <flightIdentification>
        <flightNumber>'.$flightno.'</flightNumber>
        <bookingClass>'.$bookingclass.'</bookingClass>
      </flightIdentification>
      <flightTypeDetails>
        <flightIndicator>2</flightIndicator>
      </flightTypeDetails>
      <itemNumber>'.$itemNumber.'</itemNumber>
    </segmentInformation>
  </segmentGroup>';
$itemNumber=$itemNumber+1;
$req_Fare_InformativePricingWithoutPNR.=$segment2; 
}
}
$company=$marketing; 

// <pricingOptionGroup>
//     <pricingOptionKey>
//       <pricingOptionKey>RP</pricingOptionKey>
//     </pricingOptionKey>
//   </pricingOptionGroup>
//   <pricingOptionGroup>
//     <pricingOptionKey>
//       <pricingOptionKey>RU</pricingOptionKey>
//     </pricingOptionKey>
//   </pricingOptionGroup>
//   <pricingOptionGroup>
//     <pricingOptionKey>
//       <pricingOptionKey>VC</pricingOptionKey>
//     </pricingOptionKey>
//     <carrierInformation>
//       <companyIdentification>
//         <otherCompany>'.$company.'</otherCompany>
//       </companyIdentification>
//     </carrierInformation>
//   </pricingOptionGroup>

$req_Fare_InformativePricingWithoutPNR.='</Fare_InformativePricingWithoutPNR>';
return $req_Fare_InformativePricingWithoutPNR;

}

function search_booking_itinerary_using_ref($search_data=array())
{
  extract($search_data);
  $data=read_file_from_folder($folder_config.LIST_DIR_RS,$search_id);
  $response_data=simplexml_load_string($data);
  foreach ($response_data as $key => $amadeusCustomResponse) {
    if($flightrefNumber==$amadeusCustomResponse->flightRefNumber)
    {
      $slice_flight=$amadeusCustomResponse;  
      break;
    }
  }
  return $slice_flight; 
}



$airline_code='';
//$xml_page_name=$_SESSION['src'];
$tripType=$_REQUEST['tripType'];
$FromCity=$_REQUEST['FromCity'];
$ToCity=$_REQUEST['ToCity'];
$FromDate=$_REQUEST['TravelDate'];
$ReturnTravelDate=$_REQUEST['ReturnTravelDate'];
$AdultCount=$_REQUEST['AdultCount'];
$ChildCount=$_REQUEST['ChildCount'];
$InfantCount=$_REQUEST['InfantCount'];
$CabinClass=$_REQUEST['CabinClass'];
if(isset($_REQUEST['airline_code']))
$airline_code=$_REQUEST['airline_code'];
$FromCity=substr($FromCity, 0,3);
$ToCity=substr($ToCity, 0,3);
$website_folder_name='Xprts'.'/';
//PNRACC_17_1_1A
$action_Fare_InformativePricingWithoutPNR='http://webservices.amadeus.com/TIPNRQ_18_1_1A';
$action_Air_SellFromRecommendation='http://webservices.amadeus.com/ITAREQ_05_2_IA';
$action_PNR_AddMultiElements='http://webservices.amadeus.com/PNRADD_17_1_1A';
$action_FOP_CreateFormOfPayment='http://webservices.amadeus.com/TFOPCQ_19_2_1A';
$action_Fare_PricePNRWithBookingClass='http://webservices.amadeus.com/TPCBRQ_18_1_1A';
$action_Ticket_CreateTSTFromPricing='http://webservices.amadeus.com/TAUTCQ_04_1_1A';
$action_Security_SignOut='http://webservices.amadeus.com/VLSSOQ_04_1_1A';
$action_Queue_PlacePNR='http://webservices.amadeus.com/QUQPCQ_03_1_1A';
$AMD_wbs="https://nodeD1.test.webservices.amadeus.com/1ASIWIBESXI";  

//FARQNR_07_1_1A
//$endpoint="https://nodeD1.test.webservices.amadeus.com/1ASIWIBESXI";  
$endpoint="https://nodeD1.test.webservices.amadeus.com/1ASIWFLIFBL";  
$act_fipwpnr='http://webservices.amadeus.com/TIPNRQ_18_1_1A';
$act_asfr='http://webservices.amadeus.com/ITAREQ_05_2_IA';
$act_sec_signout='http://webservices.amadeus.com/VLSSOQ_04_1_1A';
$act_fcrules='http://webservices.amadeus.com/FARQNQ_07_1_1A';
$flightrefNumber=$_GET['ref'];
$search_id=$_GET['search_id'];
$pass_data=array('flightrefNumber'=>$flightrefNumber,'triptype'=>$tripType,'adult_config'=>$AdultCount,'child_config'=>$ChildCount,'infant_config'=>$InfantCount,'folder_config'=>$website_folder_name,'search_id'=>$search_id);
$journey=array('origin'=>$FromCity,'destination'=>$ToCity,'departuredate'=>$FromDate,'returndate'=>$ReturnTravelDate);
$FIPWPNRB=body_Fare_InformativePricingWithoutPNR($pass_data,$journey);
$actions_FIPWPNR=array('action'=>$act_fipwpnr,'to'=>$endpoint,'rq'=>FIPWOP_DIR_RQ,'rs'=>FIPWOP_DIR_RS,'start'=>'1');
$rq_FIPWPNR=context_less($FIPWPNRB,$actions_FIPWPNR);
$res_Fare_InformativePricingWithoutPNR=get_generic_response($rq_FIPWPNR,$actions_FIPWPNR,$pass_data);

$Fare_InformativePricingWithoutPNR_availability=check_availability_A($res_Fare_InformativePricingWithoutPNR);
debug($res_Fare_InformativePricingWithoutPNR);

//exit;
if($Fare_InformativePricingWithoutPNR_availability===false)
{
  //echo 'aaaaaaaaaaaaaa';
  //exit;
save_file_in_folder($search_id,$website_folder_name.'Error',$res_Fare_InformativePricingWithoutPNR->asXML());  
$err_detail=$res_Fare_InformativePricingWithoutPNR->Body->Fare_InformativePricingWithoutPNRReply;
$responseType=$err_detail->messageDetails->responseType;
$errorGroup=$err_detail->errorGroup;
$errorcode=$errorGroup->errorOrWarningCodeDetails->errorDetails->errorCode;
$errortext=$errorGroup->errorWarningDescription->freeText;
$err_Fare_InformativePricingWithoutPNR='<errorDetails>
<errorOrgin>FIPWPNR</errorOrgin>
<errorCode>'.$errorcode.'</errorCode>
<errorText>'.$errortext.'</errorText>
</errorDetails>';
echo $err_Fare_InformativePricingWithoutPNR;
save_file_in_folder($search_id,$website_folder_name.'UserError',$err_Fare_InformativePricingWithoutPNR);  
exit;
}

function body_fare_checkrules()
{
  $body_farecheckrules='<Fare_CheckRules>
 <msgType>
    <messageFunctionDetails>
       <messageFunction>712</messageFunction>
    </messageFunctionDetails>
 </msgType>
 <itemNumber>
    <itemNumberDetails>
       <number>1</number>
    </itemNumberDetails>
    <itemNumberDetails>
       <number>1</number>
       <type>FC</type>
    </itemNumberDetails>
 </itemNumber>
</Fare_CheckRules>';
return $body_farecheckrules;
}

$session_data=Get_sessions_data($res_Fare_InformativePricingWithoutPNR);
//create_timestamp($website_folder_name,$session_data['session_id']);
$session_data['SequenceNumber']=2;

$body_farecheckrules=body_fare_checkrules();
$fcrules_A=array('action'=>$act_fcrules,'to'=>$endpoint,'rq'=>FC_Rules_DIR_RQ,'rs'=>FC_Rules_DIR_RS,'start'=>'1','session_info'=>$session_data);
$rq_fcrules=context_less($body_farecheckrules,$fcrules_A);
$res_fcrules=get_generic_response($rq_fcrules,$fcrules_A,$pass_data);

$session_data['SequenceNumber']=3;
$body_Security_SignOut=signout_body();
$Security_SignOut_A=array('action'=>$act_sec_signout,'to'=>$endpoint,'rq'=>S_SignOut_DIR_RQ,'rs'=>S_SignOut_DIR_RS,'start'=>'1','session_info'=>$session_data);
$rq_Security_SignOut=context_less($body_Security_SignOut,$Security_SignOut_A);
$res_Security_SignOut=get_generic_response($rq_Security_SignOut,$Security_SignOut_A,$pass_data);





?>
