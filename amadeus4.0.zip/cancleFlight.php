<?php
session_start();
//error_reporting(0);
$json_data = file_get_contents('php://input');
$data      = json_decode($json_data, true);
if ($data['flightsuppliers'] != '') {
    $flight_sup = base64_decode($data['flightsuppliers']);
    $dflight    = json_decode($flight_sup, true);
    $username   = $dflight['username'];
    $password   = $dflight['password'];
    $officeid   = $dflight['officeid'];
    $code       = $dflight['code'];
    $endpoint   = $dflight['endpoint'];
    $version    = $dflight['version'];
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect Credentials');
    echo json_encode($errr);
    exit;
}
define('userName', $username);
define('password', $password);
define('office_id', $officeid);
define('AgentDutyCode', $code);
define('endpoint_uri', $endpoint);
define('master_pricer_mptbq', 'http://webservices.amadeus.com/' . $version);
define('queue_number_details', '33');
include 'AmadeusService.php';
include 'apphead.php';
include 'appbody.php';

$organizationid  = $data['organizationId'];
$searchid        = $data['searchID'];
$flightRefNumber = $data['flightRefNumber'];
$pax             = $data['pax'];

$adult_validate  = count($pax['adult']);
$array_adult=validate_passenger_data($pax['adult']);

//$array_adult = array(array('fname' => 'Germain', 'surname' => 'Bolanos', 'dob' => '20SEP85', 'gender' => 'M'), array('fname' => 'Shreya', 'surname' => 'Ghoshal', 'dob' => '12SEP91', 'gender' => 'F'), array('fname' => 'Raushan', 'surname' => 'Kumar', 'dob' => '09JUL92', 'gender' => 'M'));
//debug($array_adult);
//exit;



if (!empty($pax['child'])) {
    $child_validate = count($pax['child']);
    $array_child=validate_passenger_data($pax['child']);

  //  $array_child = array(array('fname' => 'Sanju', 'surname' => 'Samsung', 'dob' => '17SEP12', 'gender' => 'M'), array('fname' => 'Raushan', 'surname' => 'Mahnama', 'dob' => '18SEP13', 'gender' => 'M'));

} else {
 $child_validate  = 0;
}

if (!empty($pax['infant'])) {
    $infant_validate = count($pax['infant']);
     $array_infant=validate_passenger_data($pax['infant'],'infant');
   // $array_infant    = array(array('fname' => 'Divyansi', 'surname' => 'Kumari', 'dob' => '04SEP19', 'gender' => 'FI'), array('fname' => 'Priyanshu', 'surname' => 'Ranjan', 'dob' => '09SEP19', 'gender' => 'MI'));
} else {
    $infant_validate = 0;
}

///////////////////////////credit card info parse/////////////////////////
$payment_data     = $data['paymentInfo'];
$cardType         = $payment_data['type'];
$vendorCode       = $payment_data['vendorCode'];
$cardNumber       = $payment_data['cardNumber'];
$securityId       = $payment_data['securityId'];
$cardExpiry       = str_replace('/', '', $payment_data['expiryDate']);
$credit_card_info = array('cardType' => $cardType, 'securityId' => $securityId, 'vendorCode' => $vendorCode, 'cardNumber' => $cardNumber, 'cardExpiry' => $cardExpiry);
//$credit_card_info = array('cardType' => 'CC', 'securityId' => '123', 'vendorCode' => 'VI', 'cardNumber' => '4000000000000002', 'cardExpiry' => '1222');
//exit;
//////////////////////////end credit card info////////////////////////////

//debug($credit_card_info);
//exit;

$folder_config = 'Xprts' . '/';
save_json_file($searchid, $folder_config . USERR_PNRREQUEST, $json_data);
$json_search_request = read_json_file($searchid, $folder_config . USERR_REQUEST);
$search_array        = json_decode($json_search_request, true);

$adult_config  = $search_array['adults'];
$child_config  = $search_array['childs'];
$infant_config = $search_array['infants'];

if ($adult_config == $adult_validate && $child_config == $child_validate && $infant_validate == $infant_config) {
    $triptype      = strtolower($search_array['tripType']);
    $classtype     = $search_array['classType'];
    $origin        = $search_array['origin'];
    $destination   = $search_array['destination'];
    $departuredate = $search_array['departureDate'];
    $returndate    = $search_array['returnDate'];
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect Validation Request');
    echo json_encode($errr);
    exit;
}

if ($triptype == 'roundtrip') {
    $triptype = 1;
} else if ($triptype == 'oneway') {
    $triptype = 0;
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorect Trip Type');
    echo json_encode($errr);
    exit;
}

$action_PnrRetrive     = 'http://webservices.amadeus.com/PNRRET_17_2_1A'; //PNRRET_11_1_1A';
$action_docIssueTicket = 'http://webservices.amadeus.com/TTKTIQ_15_1_1A';
$action_PnrCancel      = 'http://webservices.amadeus.com/PNRXCL_19_3_1A'; //PNRACC_14_2_1A';

$pass_data = array('flightrefNumber' => $flightRefNumber, 'triptype' => $triptype, 'adult_config' => $adult_config, 'child_config' => $child_config, 'infant_config' => $infant_config, 'folder_config' => $folder_config, 'search_id' => $searchid);
$journey   = array('origin' => $origin, 'destination' => $destination, 'departuredate' => $departuredate, 'returndate' => $returndate);
//Add multielements start here

function body_PNR_Retrieve($pnr_element)
{
    extract($pnr_element);
    $pnr_retrive = '<PNR_Retrieve>
  <retrievalFacts>
    <retrieve>
      <type>2</type>
    </retrieve>
    <reservationOrProfileIdentifier>
      <reservation>
        <controlNumber>' . $controlNumber . '</controlNumber>
      </reservation>
    </reservationOrProfileIdentifier>
  </retrievalFacts>
</PNR_Retrieve>';
    return $pnr_retrive;
}

if (!empty($pnr_element['controlNumber'])) {
    $bpnr_Retrive       = body_PNR_Retrieve($pnr_element);
    $actions_PnrRetrive = array('action' => $action_PnrRetrive, 'to' => endpoint_uri, 'rq' => PNR_Retrieve_DIR_RQ, 'rs' => PNR_Retrieve_DIR_RS);
    $rq_PnrRetrive      = context_less($bpnr_Retrive, $actions_PnrRetrive);
    $res_PnrRetrive     = get_generic_response($rq_PnrRetrive, $actions_PnrRetrive, $pass_data);
    debug($res_PnrRetrive);
    exit;
}

function body_PNR_Cancel($controlNumber)
{
    $body_cancle = '<PNR_Cancel
    xmlns="http://xml.amadeus.com/PNRXCL_19_3_1A">
    <reservationInfo>
        <reservation>
            <controlNumber>' . $controlNumber . '</controlNumber>
        </reservation>
    </reservationInfo>
    <pnrActions>
        <optionCode>0</optionCode>
    </pnrActions>
    <cancelElements>
        <entryType>S</entryType>
    </cancelElements>
</PNR_Cancel>';
    return $body_cancle;
}

if (!empty($pnr_element['controlNumber'])) {
    $controlNumber     = $pnr_element['controlNumber'];
    $bpnr_Cancel       = body_PNR_Cancel($controlNumber);
    $actions_PNRCancel = array('action' => $action_PnrCancel, 'to' => endpoint_uri, 'rq' => PNRCancle_DIR_RQ, 'rs' => PNRCancle_DIR_RS);
    $rq_PnrCancle      = context_less($bpnr_Cancel, $actions_PNRCancel);
    $res_PnrCancle     = get_generic_response($rq_PnrCancle, $actions_PNRCancel, $pass_data);
    debug($res_PnrCancle);
    exit;
}
?>