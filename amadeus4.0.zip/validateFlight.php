<?php
session_start();
error_reporting(0);
$json_data = file_get_contents('php://input');
$data      = json_decode($json_data, true);
if ($data['flightsuppliers'] != '') {
    $flight_sup = base64_decode($data['flightsuppliers']);
    $dflight    = json_decode($flight_sup, true);
     unset($data['flightsuppliers']);
    $json_data=json_encode($data);
    $username   = $dflight['username'];
    $password   = $dflight['password'];
    $officeid   = $dflight['officeid'];
    $code       = $dflight['code'];
    $endpoint   = $dflight['endpoint'];
    $version    = $dflight['version'];
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect Credentials');
    echo json_encode($errr);
    exit;
}
define('userName', $username);
define('password', $password);
define('office_id', $officeid);
define('AgentDutyCode', $code);
define('endpoint_uri', $endpoint);
define('master_pricer_mptbq', 'http://webservices.amadeus.com/' . $version);
define('queue_number_details','33'); 
include('AmadeusService.php');
include('apphead.php');
include('appbody.php');
//include('func_validate_booking.php');
  //$json_data=file_get_contents('php://input');
       // $data=json_decode($json_data,true);
        $folder_config='Xprts'.'/';
        if(empty($data))
        {
        $organizationid=$this->input->get('organizationId');  
        $searchid=$this->input->get('searchID');  
        $flightRefNumber=$this->input->get('flightRefNumber');  
        $adult_validate=$this->input->get('adults');  
        $child_validate=$this->input->get('childs');  
        $infant_validate=$this->input->get('infants');  
          if($organizationId=='' || $searchID=='' || $flightRefNumber=='' ||$adult_config=='' ||$child_config=='' ||$infant_config=='')
          {
          $errr=array('status'=>'Fail','error'=>'Incorrect Verification Input');
            echo json_encode($errr);
            exit;

          }
          else
          {
            $json_data=json_encode($_GET);
          }
        }
        else
        {
        $organizationid=$data['organizationId'];
        $searchid=$data['searchID'];
        $flightRefNumber=$data['flightRefNumber'];
        $adult_validate=$data['adults'];
        $child_validate=$data['childs'];
        $infant_validate=$data['infants'];
        }
        save_json_file($searchid,$folder_config.VALIDATE_REQUEST,$json_data);
       $json_search_request=read_json_file($searchid,$folder_config.USERR_REQUEST);
        $search_array=json_decode($json_search_request,true);
        
        $adult_config=$search_array['adults'];
        $child_config=$search_array['childs'];
        $infant_config=$search_array['infants'];

        if($adult_config==$adult_validate && $child_config==$child_validate && $infant_validate==$infant_config)
        {
        $triptype=strtolower($search_array['tripType']);
        $classtype=$search_array['classType'];
        $origin=$search_array['origin'];
        $destination=$search_array['destination'];
        $departuredate=$search_array['departureDate'];
        $returndate=$search_array['returnDate'];
        }
        else
        {
        $errr=array('status'=>'Fail','error'=>'Incorrect Passenger Count');
            echo json_encode($errr);
            exit;
        }

        $search_data['folder_config']=$folder_config;
        $search_data['flightrefNumber']=$flightRefNumber;
        $search_data['search_id']=$searchid;

        $flight_itenary=search_booking_itinerary_using_ref($search_data);
        //debug($flight_itenary);
        if(empty($flight_itenary))  
        {
          $errr=array('status'=>'Fail','error'=>'Iteneary Not found');
            echo json_encode($errr);
            exit;
        }
//exit;
        $pass_data=array('flightrefNumber'=>$flightRefNumber,'triptype'=>$triptype,'adult_config'=>$adult_config,'child_config'=>$child_config,'infant_config'=>$infant_config,'folder_config'=>$folder_config,'search_id'=>$searchid);
$journey=array('origin'=>$origin,'destination'=>$destination,'departuredate'=>$departuredate,'returndate'=>$returndate);

$act_fipwpnr='http://webservices.amadeus.com/TIPNRQ_18_1_1A';
$act_asfr='http://webservices.amadeus.com/ITAREQ_05_2_IA';
$act_sec_signout='http://webservices.amadeus.com/VLSSOQ_04_1_1A';
$FIPWPNRB=body_Fare_InformativePricingWithoutPNR($pass_data,$journey);
$actions_FIPWPNR=array('action'=>$act_fipwpnr,'to'=>endpoint_uri,'rq'=>FIPWOP_DIR_RQ,'rs'=>FIPWOP_DIR_RS);
$rq_FIPWPNR=context_less($FIPWPNRB,$actions_FIPWPNR);
$res_Fare_InformativePricingWithoutPNR=get_generic_response($rq_FIPWPNR,$actions_FIPWPNR,$pass_data);

if(!empty($res_Fare_InformativePricingWithoutPNR->Body->Fault))
{
handle_soap_foalt($res_Fare_InformativePricingWithoutPNR->Body->Fault,'0');
}

//debug($res_Fare_InformativePricingWithoutPNR);
$Fare_InformativePricingWithoutPNR_availability=check_availability_A($res_Fare_InformativePricingWithoutPNR);

  if($Fare_InformativePricingWithoutPNR_availability===false)
{
save_file_in_folder($searchid,$folder_config.ERR_DIR,$res_Fare_InformativePricingWithoutPNR->asXML());  
$err_detail=$res_Fare_InformativePricingWithoutPNR->Body->Fare_InformativePricingWithoutPNRReply;
$responseType=$err_detail->messageDetails->responseType;
$errorGroup=$err_detail->errorGroup;
$errortext=$errorGroup->errorWarningDescription->freeText;
echo $json_err='{
    "status": "Fail",
    "error": "'.$errortext.'"
      }';
save_json_file($searchid,$folder_config.USERR_DIR,$json_err);
//save_file_in_folder($searchid,$folder_config.USERR_DIR,$err_Fare_InformativePricingWithoutPNR);  
exit;
}
$ASFR_B=body_Air_SellFromRecommendation($pass_data,$journey);
$ASFR_A=array('action'=>$act_asfr,'to'=>endpoint_uri,'rq'=>AIRSFR_DIR_RQ,'rs'=>AIRSFR_DIR_RS,'start'=>'1');
$rq_ASFR=context_less($ASFR_B,$ASFR_A);
$res_Air_SellFromRecommendation=get_generic_response($rq_ASFR,$ASFR_A,$pass_data);
if(!empty($res_Air_SellFromRecommendation->Body->Fault))
{
handle_soap_foalt($res_Air_SellFromRecommendation->Body->Fault,'1');
}

//debug($res_Air_SellFromRecommendation);
//exit;
//
$validate_response='{
    "organizationId": "1",
    "searchID": "'.$searchid.'",
    "flightRefNumber": "'.$flightRefNumber.'",
    "adults": "'.$adult_config.'",
    "childs": "'.$child_config.'",
    "infants": "'.$infant_config.'",';
    //debug($res_Air_SellFromRecommendation);
$SellFromRecommendation_status=chk_status_ok_Air_SellFromRecommendation($res_Air_SellFromRecommendation);
if(empty($SellFromRecommendation_status))
{
  $check_error=$res_Air_SellFromRecommendation->Body->Air_SellFromRecommendationReply->errorAtMessageLevel;
//debug($check_error);
$errorcode=$check_error->errorSegment->errorDetails->errorCode;
  if($errorcode=='288')
  {
    $errortext='Flight has not confirm,Please Try another flight';
  }
  else
  {
    $errortext='';
  }

echo $json_err='{
    "status": "Fail",
    "error": "'.$errortext.'"
      }';
save_json_file($searchid,$folder_config.USERR_DIR,$json_err);
//echo $err_Fare_InformativePricingWithoutPNR;
//debug($check_error);
if(!empty($check_error))
{
save_file_in_folder($searchid,$folder_config.ERR_DIR,$check_error->asXML());   
}
$session_data=get_header_info($res_Air_SellFromRecommendation);
$body_Security_SignOut=signout_body();
$Security_SignOut_A=array('action'=>$act_sec_signout,'to'=>endpoint_uri,'rq'=>S_SignOut_DIR_RQ,'rs'=>S_SignOut_DIR_RS,'start'=>'1','session_info'=>$session_data);
$rq_Security_SignOut=context_less($body_Security_SignOut,$Security_SignOut_A);
$res_Security_SignOut=get_generic_response($rq_Security_SignOut,$Security_SignOut_A,$pass_data);
exit;
}
else if($SellFromRecommendation_status)
{
//check fare is increased
$fare_check=check_fare($res_Fare_InformativePricingWithoutPNR); // 
//$fipwpnr_fare=calculate_total_fare_fipwpnr($fare_check); //get total fare after in fipw/opnro
$fipwpnr_totalfare=calculate_total_fare_fipwpnr($fare_check); //get total fare after in fipw/opnro
//get flightlist fare
//debug($fare_check);
//debug($fipwpnr_fare);

$fipwpnr_fare=$fipwpnr_totalfare['total_fare'];
$fipwpnr_basefare=$fipwpnr_totalfare['total_base_fare'];
$tax_fipwpnr=(float)$fipwpnr_fare - (float)$fipwpnr_basefare;

 $flightListsearch_fare=search_booking_itinerary_using_ref($pass_data);
 $totalflightlist_fare=(float)$flightListsearch_fare->paxFareProduct->totalFare;
//check fare increase
if(abs($fipwpnr_fare) > abs($totalflightlist_fare))
{
$increase_fare_amt=(float)$fipwpnr_fare - (float)$totalflightlist_fare;
$fare_tobookFlight=$fipwpnr_fare;
$total_base_fare=$fipwpnr_basefare;
$total_tax=$tax_fipwpnr;
}
else
{
$increase_fare_amt=0;
$fare_tobookFlight=$totalflightlist_fare;
$total_base_fare=(float)$flightListsearch_fare->paxFareProduct->totalbaseFare;
$total_tax=(float)$flightListsearch_fare->paxFareProduct->totaltax;
}
$book_seg='';
$booking_status=get_flight_number_booking_class($res_Air_SellFromRecommendation);
$session_data=get_header_info($res_Air_SellFromRecommendation);
//create_timestamp($session_data['session_id'],$pass_data);
$flights_det='"flightStatus": [';
$c_seg=count($booking_status);
foreach ($booking_status as $key => $fly) {
if($key==($c_seg-1))
{
 $book_seg.='"'.$fly['flightNumber'][0].'|'.$fly['bookingClass'][0].'| FlightStatus:'.$fly['flightStatus'][0].'"';
 
}else{
  $book_seg.='"'.$fly['flightNumber'][0].'|'.$fly['bookingClass'][0].'| FlightStatus:'.$fly['flightStatus'][0].'",';
} 
 
}
$flights_det.=$book_seg;
$flights_det.='],';
$validate_response.='"sessionType": {
        "sessionId": "'.$session_data['session_id'].'",
        "sequenceNumber": "'.$session_data['SequenceNumber'].'",
        "securityToken": "'.$session_data['SecurityToken'].'",
        "transactionStatusCode": null
    },';

 $validate_response.=$flights_det;
    $validate_response.='"totalbaseFare": "'.$total_base_fare.'","totalTax": "'.$total_tax.'","totalFare": "'.$fare_tobookFlight.'",
    "status":"Success",
    "error":null,"fare_Increase":"'.$increase_fare_amt.'"
}';
 echo $validate_response;
 save_json_file($searchid,$folder_config.VALIDATE_RESPONSE,$validate_response);
$dat4e=strtotime("+14 minutes",strtotime(date('Y-m-d H:i:s')));
$sessions_data='{"searchID": "'.$searchid.'", "flightRefNumber": "'.$flightRefNumber.'","expiry": "'.$dat4e.'","currentSearchId": "unlock"}';
 save_json_file($searchid,$folder_config.VALIDATE_PNRSESSION,$sessions_data);
 exit;
}   
