<?php 
function body_Fare_PricePNRWithBookingClass($airline_code)
{
  $b='<Fare_PricePNRWithBookingClass>
  <pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>VC</pricingOptionKey>
    </pricingOptionKey>
    <carrierInformation>
      <companyIdentification>
        <otherCompany>'.$airline_code.'</otherCompany>
      </companyIdentification>
    </carrierInformation>
  </pricingOptionGroup>
  <pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>RP</pricingOptionKey>
    </pricingOptionKey>
  </pricingOptionGroup>
  <pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>RU</pricingOptionKey>
    </pricingOptionKey>
  </pricingOptionGroup>
   <pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>FCO</pricingOptionKey>
    </pricingOptionKey>
    <currency>
      <firstCurrencyDetails>
        <currencyQualifier>FCO</currencyQualifier>
        <currencyIsoCode>USD</currencyIsoCode>
      </firstCurrencyDetails>
    </currency>
  </pricingOptionGroup>
</Fare_PricePNRWithBookingClass>';
return $b;
}

function queu_place_pnrb($inhouse)
{
extract($inhouse);
$queue='<Queue_PlacePNR>
  <placementOption>
    <selectionDetails>
      <option>QEQ</option>
    </selectionDetails>
  </placementOption>
  <targetDetails>
    <targetOffice>
      <sourceType>
        <sourceQualifier1>3</sourceQualifier1>
      </sourceType>
      <originatorDetails>
        <inHouseIdentification1>'.$inHouseIdentification1.'</inHouseIdentification1>
      </originatorDetails>
    </targetOffice>
    <queueNumber>
      <queueDetails>
        <number>'.queue_number_details.'</number>
      </queueDetails>
    </queueNumber>
    <categoryDetails>
      <subQueueInfoDetails>
        <identificationType>C</identificationType>
        <itemNumber>0</itemNumber>
      </subQueueInfoDetails>
    </categoryDetails>
  </targetDetails>
  <recordLocator>
    <reservation>
      <controlNumber>'.$controlNumber.'</controlNumber>
    </reservation>
  </recordLocator>
</Queue_PlacePNR>';

return $queue;
}

function body_DocIssuance_IssueTicket()
{
 $DocIssuance='<DocIssuance_IssueTicket>
  <optionGroup>
    <switches>
      <statusDetails>
        <indicator>ET</indicator>
      </statusDetails>
    </switches>
  </optionGroup>
</DocIssuance_IssueTicket>';
return $DocIssuance;
}



function create_ssrb($PT_From_PNR_AddMultiElements,$array_adult,$array_child,$array_infant)
{
$rq_PNR_AddMultiElements_ssr='<PNR_AddMultiElements>
  <pnrActions>
    <optionCode>11</optionCode>
      <optionCode>30</optionCode>
  </pnrActions>
  <dataElementsMaster>
    <marker1 />';
$ssr_document='';
foreach ($PT_From_PNR_AddMultiElements as $key => $traveler_info) {
//debug($traveler_info);
$passenger_ssr=create_passenger_SSR($traveler_info,$array_adult,$array_child,$array_infant);
 $ssr_document.=$passenger_ssr;
}
$rq_PNR_AddMultiElements_ssr.=$ssr_document;
$rq_PNR_AddMultiElements_ssr.='</dataElementsMaster>';
$rq_PNR_AddMultiElements_ssr.='</PNR_AddMultiElements>';
return $rq_PNR_AddMultiElements_ssr;
}

function create_passenger_SSR($traveler_info,$array_adult='',$array_child='',$array_infant='')
{
$ssr_doc='';
$Pt_number=$traveler_info->elementManagementPassenger->reference->number;
$enhancedPassengerData=$traveler_info->enhancedPassengerData;
$Isinfant='';
foreach ($enhancedPassengerData as $key => $passenger) {
$Isinfant=$passenger->enhancedTravellerInformation->travellerNameInfo->infantIndicator;
$ptype=$passenger->enhancedTravellerInformation->travellerNameInfo->type;
$sur_name=$passenger->enhancedTravellerInformation->otherPaxNamesDetails->surname;
$first_name=$passenger->enhancedTravellerInformation->otherPaxNamesDetails->givenName;
if($ptype=='ADT')
{
$pax_index=searchForName_SSR($first_name,$sur_name,$array_adult,$ptype);  
$pax_info=$array_adult[$pax_index];  
}
else if($ptype=='CHD')
{
$pax_index=searchForName_SSR($first_name,$sur_name,$array_child,$ptype);  
$pax_info=$array_child[$pax_index];  
}
else if($ptype=='INF')
{
$pax_index=searchForName_SSR($first_name,$sur_name,$array_infant,$ptype);  
$pax_info=$array_infant[$pax_index];  
}
$fname=strtoupper($pax_info['fname']);
$surname=strtoupper($pax_info['surname']);
$dob=strtoupper($pax_info['dob']);
$gender=strtoupper($pax_info['gender']);
//<freetext>----'.$dob.'-'.$gender.'--'.$surname.'-'.$fname.'</freetext>
////12SEP91/F//DEVI/SITA
$ssr_document='
    <dataElementsIndiv>
      <elementManagementData>
        <segmentName>SSR</segmentName>
      </elementManagementData>
      <serviceRequest>
        <ssr>
          <type>DOCS</type>
          <status>HK</status>
          <quantity>1</quantity>
          <companyId>YY</companyId>
          <freetext>----'.$dob.'-'.$gender.'--'.$surname.'-'.$fname.'</freetext>
        </ssr>
      </serviceRequest>
      <referenceForDataElement>
        <reference>
          <qualifier>PT</qualifier>
          <number>'.$Pt_number.'</number>
        </reference>
      </referenceForDataElement>
    </dataElementsIndiv>';
$ssr_doc.=$ssr_document;
}
return $ssr_doc;
}

function searchForName_SSR($fname,$surname='',$array,$ptype) {
   foreach ($array as $key => $val) {
     if($ptype=='ADT' || $ptype=='CHD')
     {
      $rq_fname=strtoupper($val['fname']);
      $rq_surname=strtoupper($val['surname']);
       if ($rq_fname==$fname && $rq_surname==$surname) 
       {
          return $key;
       }
     }
     else
     {
      $rq_fname=strtoupper($val['fname']);
      $rq_surname=strtoupper($val['surname']);
       $infant_name=$rq_fname.' '.$rq_surname; 
       if ($infant_name==$fname) 
       {
          return $key;
       }
     }   
   }
   return null;
}

function body_Ticket_CreateTSTFromPricing($pass_data)
{
  extract($pass_data);
 $rq_TST='<Ticket_CreateTSTFromPricing>';
 $tst_reference=1;
 if($adult_config>0)
{
 $rq_TST.='<psaList>
    <itemReference>
      <referenceType>TST</referenceType>
      <uniqueReference>'.$tst_reference.'</uniqueReference>
    </itemReference>
  </psaList>';
  $tst_reference=$tst_reference + 1;
}

if($child_config>0)
{
 $rq_TST.='<psaList>
    <itemReference>
      <referenceType>TST</referenceType>
      <uniqueReference>'.$tst_reference.'</uniqueReference>
    </itemReference>
  </psaList>';
  $tst_reference=$tst_reference + 1;
}

if($infant_config>0)
{
 $rq_TST.='<psaList>
    <itemReference>
      <referenceType>TST</referenceType>
      <uniqueReference>'.$tst_reference.'</uniqueReference>
    </itemReference>
  </psaList>';
}
$rq_Ticket_CreateTSTFromPricing=$rq_TST.'</Ticket_CreateTSTFromPricing>';
return $rq_Ticket_CreateTSTFromPricing;
}

function body_FOP_CreateFormOfPayment($credit_card_info)
{
extract($credit_card_info);


 return $fop_withOutCreditCard='<FOP_CreateFormOfPayment>
      <transactionContext>
        <transactionDetails>
          <code>FP</code>
        </transactionDetails>
      </transactionContext>
      <fopGroup>
        <fopReference/>
        <mopDescription>
          <fopSequenceNumber>
            <sequenceDetails>
              <number>1</number>
            </sequenceDetails>
          </fopSequenceNumber>
          <mopDetails>
            <fopPNRDetails>
              <fopDetails>
                <fopCode>CASH</fopCode>
              </fopDetails>
            </fopPNRDetails>
          </mopDetails>
        </mopDescription>
      </fopGroup>
    </FOP_CreateFormOfPayment>';




$CreateFormOfPayment='<FOP_CreateFormOfPayment>
  <fopGroup>
    <fopReference />
    <mopDescription>
      <fopSequenceNumber>
        <sequenceDetails>
          <number>1</number>
        </sequenceDetails>
      </fopSequenceNumber>
      <mopDetails>
        <fopPNRDetails>
          <fopDetails>
            <fopCode>CC'.$vendorCode.'</fopCode>
          </fopDetails>
        </fopPNRDetails>
      </mopDetails>
      <paymentModule>
        <groupUsage>
          <attributeDetails>
            <attributeType>FP</attributeType>
          </attributeDetails>
        </groupUsage>
        <mopInformation>
          <fopInformation>
            <formOfPayment>
              <type>'.$cardType.'</type>
            </formOfPayment>
          </fopInformation>
          <dummy />
          <creditCardData>
            <creditCardDetails>
              <ccInfo>
                <vendorCode>'.$vendorCode.'</vendorCode>
                <cardNumber>'.$cardNumber.'</cardNumber>
                <securityId>'.$securityId.'</securityId>
                <expiryDate>'.$cardExpiry.'</expiryDate>
              </ccInfo>
            </creditCardDetails>
          </creditCardData>
        </mopInformation>
        <dummy />
      </paymentModule>
    </mopDescription>
  </fopGroup>';
$CreateFormOfPayment.='</FOP_CreateFormOfPayment>';
return $CreateFormOfPayment;
}

function body_Fare_MasterPricerTravelBoardSearch($pass_data,$journey,$flight_type='',$includeAirlines=array(),$excludeAirlines=array())
{
extract($pass_data); 
//$limit=1;
$carrier='';
$carrierx='';
$total_passenger=$adult_config + $child_config;
$request_soap='<Fare_MasterPricerTravelBoardSearch>
  <numberOfUnit>
   <unitNumberDetail>
    <numberOfUnits>'.$total_passenger.'</numberOfUnits>
    <typeOfUnit>PX</typeOfUnit>
   </unitNumberDetail>
   <unitNumberDetail>
    <numberOfUnits>'.$limit.'</numberOfUnits>
    <typeOfUnit>RC</typeOfUnit>
   </unitNumberDetail>
  </numberOfUnit>
  <paxReference>
   <ptc>ADT</ptc>';
   $request_soap_adult='';
   $request_soap_child='';
   $request_soap_infant='';
for($adult=1;$adult<=$adult_config;$adult++)
{
   $request_soap_adult.='<traveller>
    <ref>'.$adult.'</ref>
   </traveller>';
   
}
$request_soap.=$request_soap_adult;
$request_soap.='</paxReference>';
 if($child_config>0)
 { 
 $child_loop_disconnect=$adult_config + $child_config; 
 $request_soap_child.='<paxReference><ptc>CNN</ptc>';
for($child=$adult;$child<=$child_loop_disconnect;$child++)
{
   $request_soap_child.='<traveller>
    <ref>'.$child.'</ref>
   </traveller>';
}
$request_soap_child.='</paxReference>';
$request_soap.=$request_soap_child;
 }
 if($infant_config>0)
 { 
 $request_soap_infant.='<paxReference><ptc>INF</ptc>';
for($infant=1;$infant<=$infant_config;$infant++)
{
   $request_soap_infant.='<traveller>
    <ref>'.$infant.'</ref>
    <infantIndicator>'.$infant.'</infantIndicator>
   </traveller>';
}
$request_soap_infant.='</paxReference>';
$request_soap.=$request_soap_infant;
 }

// <fareOptions>
// <pricingTickInfo>
// <pricingTicketing>
// <priceType>CUC</priceType>
// </pricingTicketing>
// </pricingTickInfo>
// <conversionRate>
// <conversionRateDetail>
// <currency>USD</currency>
// </conversionRateDetail>
// </conversionRate>
// </fareOptions>

 // <fareOptions>
 //        <pricingTickInfo>
 //           <pricingTicketing>
 //              <priceType>RP</priceType>
 //              <priceType>RU</priceType>
 //              <priceType>TAC</priceType>
 //           </pricingTicketing>
 //        </pricingTickInfo>
 //    </fareOptions>
// <flightType>D</flightType>

$request_soap.='
   <fareOptions>
        <pricingTickInfo>
            <pricingTicketing>
              <priceType>ET</priceType>
               <priceType>RP</priceType>
               <priceType>RU</priceType>
               <priceType>TAC</priceType>
			         <priceType>CUC</priceType>
            </pricingTicketing>
         </pricingTickInfo>
          <conversionRate>
              <conversionRateDetail>
              <currency>USD</currency>
              </conversionRateDetail> 
           </conversionRate>
     </fareOptions>';



$request_soap.='<travelFlightInfo>';
$airlines_incexc=false;
if(!empty($includeAirlines))
{
$airlines_incexc=true;
    $request_soap.='<companyIdentity>
      <carrierQualifier>M</carrierQualifier>';
      foreach ($includeAirlines as $key => $value) {
      $carrier.='<carrierId>'.$includeAirlines[$key].'</carrierId>';
      }
     $request_soap.=$carrier; 
    $request_soap.='</companyIdentity>';
}

if(!empty($excludeAirlines))
{
$airlines_incexc=true;
 $request_soap.='
    <companyIdentity>
      <carrierQualifier>X</carrierQualifier>';
      foreach ($excludeAirlines as $key => $value) {
      $carrierx.='<carrierId>'.$excludeAirlines[$key].'</carrierId>';
      }
     $request_soap.=$carrierx; 
    $request_soap.='</companyIdentity>';
}

if($airlines_incexc==false)
{
 $request_soap.='  <cabinId>
   <cabin>'.$cabin.'</cabin>
   </cabinId>
   <flightDetail>';
if($flight_type!='')
{
    $request_soap.='<flightType>'.$flight_type.'</flightType>'; 
}
else
{
  $request_soap.='<flightType>N</flightType>
                <flightType>C</flightType>
                <flightType>D</flightType>'; 
}
$request_soap.='</flightDetail>'; 
}
$request_soap.='</travelFlightInfo>';
   
   
  extract($journey); 
$request_soap.='<itinerary>
<requestedSegmentRef>
<segRef>1</segRef>
</requestedSegmentRef>
<departureLocalization>
<departurePoint>
<locationId>'.$origin.'</locationId>
</departurePoint>
</departureLocalization>
<arrivalLocalization>
<arrivalPointDetails>
<locationId>'.$destination.'</locationId>
</arrivalPointDetails>
</arrivalLocalization>
<timeDetails>
<firstDateTimeDetail>
<date>'.$departuredate.'</date>
</firstDateTimeDetail>
</timeDetails>
</itinerary>';
if($triptype!=0)
{
$request_soap.='<itinerary>
<requestedSegmentRef>
<segRef>2</segRef>
</requestedSegmentRef>
<departureLocalization>
<departurePoint>
<locationId>'.$destination.'</locationId>
</departurePoint>
</departureLocalization>
<arrivalLocalization>
<arrivalPointDetails>
<locationId>'.$origin.'</locationId>
</arrivalPointDetails>
</arrivalLocalization>
<timeDetails>
<firstDateTimeDetail>
<date>'.$returndate.'</date>
</firstDateTimeDetail>
</timeDetails>
</itinerary>';
}
$request_soap.='</Fare_MasterPricerTravelBoardSearch>';
return $request_soap;
}



function body_PNR_AddMultiElements($pass_data,$journey,$array_adult,$array_child,$array_infant)
{
extract($pass_data);
  $pnr_addmultielement='<PNR_AddMultiElements>
  <pnrActions>
    <optionCode>0</optionCode>
  </pnrActions>';
$qualifier_number=1;
$pnr_addmultielementwith_infant='';

for($adt=1;$adt<=$adult_config;$adt++)
{
$k=$adt-1;
$fname=$array_adult[$k]['fname'];
$surname=$array_adult[$k]['surname'];

//22042019
if($adt<=$infant_config)
{
$infant_name=$array_infant[$k]['fname'].' '.$array_infant[$k]['surname'];
$infant_dob=$array_infant[$k]['dob'];
$pnr_addmultielementwith_infant.='<travellerInfo>
    <elementManagementPassenger>
      <reference>
        <qualifier>PR</qualifier>
        <number>'.$qualifier_number.'</number>
      </reference>
      <segmentName>NM</segmentName>
    </elementManagementPassenger>
    <passengerData>
      <travellerInformation>
        <traveller>
          <surname>'.$surname.'</surname>
          <quantity>2</quantity>
        </traveller>
        <passenger>
          <firstName>'.$fname.'</firstName>
          <type>ADT</type>
          <infantIndicator>2</infantIndicator>
        </passenger>
        <passenger>
          <firstName>'.$infant_name.'</firstName>
          <type>INF</type>
        </passenger>
      </travellerInformation>
      <dateOfBirth>
        <dateAndTimeDetails>
          <qualifier>706</qualifier>
          <date>'.$infant_dob.'</date>
        </dateAndTimeDetails>
      </dateOfBirth>
    </passengerData>
  </travellerInfo>';
}
else 
{
  $pnr_addmultielementwith_infant.='<travellerInfo>
    <elementManagementPassenger>
      <reference>
        <qualifier>PR</qualifier>
        <number>'.$qualifier_number.'</number>
      </reference>
      <segmentName>NM</segmentName>
    </elementManagementPassenger>
    <passengerData>
      <travellerInformation>
        <traveller>
          <surname>'.$surname.'</surname>
          <quantity>1</quantity>
        </traveller>
        <passenger>
          <firstName>'.$fname.'</firstName>
          <type>ADT</type>
        </passenger>
      </travellerInformation>
    </passengerData>
  </travellerInfo>';
}
$qualifier_number=$qualifier_number+1;
}

$pnr_addmultielement.=$pnr_addmultielementwith_infant;
$pnr_addmultielement_with_child='';

//PR Passenger Client-request-message-defined ref. nbr
//NM Name element

for($chd=1;$chd<=$child_config;$chd++)
{
$k=$chd-1;
$fname=$array_child[$k]['fname'];
$surname=$array_child[$k]['surname'];
$child_dob=$array_child[$k]['dob'];
//01052015
  $pnr_addmultielement_with_child.='
  <travellerInfo>
    <elementManagementPassenger>
      <reference>
        <qualifier>PR</qualifier>
        <number>'.$qualifier_number.'</number>
      </reference>
      <segmentName>NM</segmentName>
    </elementManagementPassenger>
    <passengerData>
      <travellerInformation>
        <traveller>
          <surname>'.$surname.'</surname>
          <quantity>1</quantity>
        </traveller>
        <passenger>
          <firstName>'.$fname.'</firstName>
          <type>CHD</type>
        </passenger>
      </travellerInformation>
      <dateOfBirth>
        <dateAndTimeDetails>
          <qualifier>706</qualifier>
          <date>'.$child_dob.'</date>
        </dateAndTimeDetails>
      </dateOfBirth>
    </passengerData>
  </travellerInfo>';
  $qualifier_number=$qualifier_number+1;
}

$pnr_addmultielement.=$pnr_addmultielement_with_child;
//3 Literal text
//P21 Option information
//AP Contact element
//RF Receive From element
//P22 Receive from
//NM Name Element
//TK Ticket element
  $pnr_addmultielement.='<dataElementsMaster>
    <marker1 />
    <dataElementsIndiv>
      <elementManagementData>
        <segmentName>AP</segmentName>
      </elementManagementData>
      <freetextData>
        <freetextDetail>
          <subjectQualifier>3</subjectQualifier>
          <type>P21</type>
        </freetextDetail>
        <longFreetext></longFreetext>
      </freetextData>
    </dataElementsIndiv>

    <dataElementsIndiv>
      <elementManagementData>
        <segmentName>TK</segmentName>
      </elementManagementData>
      <ticketElement>
        <ticket>
          <indicator>OK</indicator>
        </ticket>
      </ticketElement>
    </dataElementsIndiv>

    <dataElementsIndiv>
      <elementManagementData>
        <segmentName>RF</segmentName>
      </elementManagementData>
      <freetextData>
        <freetextDetail>
          <subjectQualifier>3</subjectQualifier>
          <type>P22</type>
        </freetextDetail>
        <longFreetext>AWSUI</longFreetext>
      </freetextData>
    </dataElementsIndiv>
  </dataElementsMaster>';
$pnr_addmultielement.='</PNR_AddMultiElements>';

return $pnr_addmultielement;

}
function signout_body()
{
 return $b='<Security_SignOut xmlns="http://xml.amadeus.com/VLSSOQ_04_1_1A"> </Security_SignOut>';
}
function body_Air_SellFromRecommendation($pass_data,$journey)
{
extract($pass_data);
extract($journey);
$total_pass_exclude_infant=$adult_config + $child_config;
$depart_recomend='';
$slice_flight=search_booking_itinerary_using_ref($pass_data);
if(empty($slice_flight))
{
echo $err_flight_ref='<errorDetails>
<errorOrgin>ASFR</errorOrgin>
<errorText>Flight Reference Not Found</errorText>
</errorDetails>';
  exit;
}
$req_Air_SellFromRecommendation='<Air_SellFromRecommendation>
  <messageActionDetails>
    <messageFunctionDetails>
      <messageFunction>183</messageFunction>
      <additionalMessageFunction>M1</additionalMessageFunction>
    </messageFunctionDetails>
  </messageActionDetails>

  <itineraryDetails>
    <originDestinationDetails>
      <origin>'.$origin.'</origin>
      <destination>'.$destination.'</destination>
    </originDestinationDetails>
    <message>
      <messageFunctionDetails>
        <messageFunction>183</messageFunction>
      </messageFunctionDetails>
    </message>';
$dep_details=$slice_flight->departureFlights->flightDetails;
$segment='';
$flight_indicate=0;
//Status code NN Sell Segment
foreach ($dep_details as $key => $depsegment) {
$departure_date=$depsegment->flightInformation->productDateTime->dateOfDeparture;
$fromlocation=$depsegment->flightInformation->location[0]->locationId;
$tolocation=$depsegment->flightInformation->location[1]->locationId;
$marketing=$depsegment->flightInformation->companyId->marketingCarrier;
$operating=$depsegment->flightInformation->companyId->operatingCarrier;
$flightno=$depsegment->flightInformation->flightOrtrainNumber;
$cabin=$depsegment->cabinProduct->rbd;
$flight_indicate=$flight_indicate+1;
   $depart_recomend.='<segmentInformation>
      <travelProductInformation>
        <flightDate>
          <departureDate>'.$departure_date.'</departureDate>
        </flightDate>
        <boardPointDetails>
          <trueLocationId>'.$fromlocation.'</trueLocationId>
        </boardPointDetails>
        <offpointDetails>
          <trueLocationId>'.$tolocation.'</trueLocationId>
        </offpointDetails>
        <companyDetails>
          <marketingCompany>'.$marketing.'</marketingCompany>
        </companyDetails>
        <flightIdentification>
          <flightNumber>'.$flightno.'</flightNumber>
          <bookingClass>'.$cabin.'</bookingClass>
        </flightIdentification>';

if(!empty($depsegment->flightTypeIndicator))
{
$depart_recomend.='<flightTypeDetails>
<flightIndicator>'.$depsegment->flightTypeIndicator.'</flightIndicator>
</flightTypeDetails>';
}

     $depart_recomend.='</travelProductInformation>
      <relatedproductInformation>
        <quantity>'.$total_pass_exclude_infant.'</quantity>
        <statusCode>NN</statusCode>
      </relatedproductInformation>
    </segmentInformation>';

}
$req_Air_SellFromRecommendation.=$depart_recomend;
$req_Air_SellFromRecommendation.='</itineraryDetails>';


$arrival_r='';
$arrival_recomened='';
if(!empty($slice_flight->returnFlights->flightDetails))
{
$ret_details=$slice_flight->returnFlights->flightDetails;
$segment='';
$flight_indicate=0;

$arrival_r='<itineraryDetails>
    <originDestinationDetails>
           <origin>'.$destination.'</origin>
      <destination>'.$origin.'</destination>
    </originDestinationDetails>
    <message>
      <messageFunctionDetails>
        <messageFunction>183</messageFunction>
      </messageFunctionDetails>
    </message>';
foreach ($ret_details as $key => $depsegment) {
$departure_date=$depsegment->flightInformation->productDateTime->dateOfDeparture;
$fromlocation=$depsegment->flightInformation->location[0]->locationId;
$tolocation=$depsegment->flightInformation->location[1]->locationId;
$marketing=$depsegment->flightInformation->companyId->marketingCarrier;
$operating=$depsegment->flightInformation->companyId->operatingCarrier;
$flightno=$depsegment->flightInformation->flightOrtrainNumber;
$cabin=$depsegment->cabinProduct->rbd;
$flight_indicate=$flight_indicate+1;

    $arrival_recomened.='<segmentInformation>
      <travelProductInformation>
        <flightDate>
          <departureDate>'.$departure_date.'</departureDate>
        </flightDate>
        <boardPointDetails>
          <trueLocationId>'.$fromlocation.'</trueLocationId>
        </boardPointDetails>
        <offpointDetails>
          <trueLocationId>'.$tolocation.'</trueLocationId>
        </offpointDetails>
        <companyDetails>
          <marketingCompany>'.$marketing.'</marketingCompany>
        </companyDetails>
        <flightIdentification>
          <flightNumber>'.$flightno.'</flightNumber>
          <bookingClass>'.$cabin.'</bookingClass>
        </flightIdentification>';

if(!empty($depsegment->flightTypeIndicator))
{
$arrival_recomened.='<flightTypeDetails>
<flightIndicator>'.$depsegment->flightTypeIndicator.'</flightIndicator>
</flightTypeDetails>';
}


      $arrival_recomened.='</travelProductInformation>
      <relatedproductInformation>
        <quantity>'.$total_pass_exclude_infant.'</quantity>
        <statusCode>NN</statusCode>
      </relatedproductInformation>
    </segmentInformation>';
    }
  $arrival_r.=$arrival_recomened;
  $arrival_r.='</itineraryDetails>';
}
$req_Air_SellFromRecommendation.=$arrival_r;
$req_Air_SellFromRecommendation.='</Air_SellFromRecommendation>';
return $req_Air_SellFromRecommendation;
}


function body_Fare_InformativePricingWithoutPNR($pass_data,$journey)
{
  $quantity=1; 
  extract($pass_data);
  $req_Fare_InformativePricingWithoutPNR='';//$header_soap;
$req_Fare_InformativePricingWithoutPNR.='<Fare_InformativePricingWithoutPNR>';
  if($adult_config>0)
  {
  $request_soap_adult='<passengersGroup>
    <segmentRepetitionControl>
      <segmentControlDetails>
        <quantity>'.$quantity.'</quantity>
        <numberOfUnits>'.$adult_config.'</numberOfUnits>
      </segmentControlDetails>
    </segmentRepetitionControl>
    <travellersID>';
    for($adult=1;$adult<=$adult_config;$adult++)
    {
  $request_soap_adult.='<travellerDetails>
        <measurementValue>'.$adult.'</measurementValue>
      </travellerDetails>';
    }
    $request_soap_adult.='</travellersID>
      <discountPtc>
        <valueQualifier>ADT</valueQualifier>
      </discountPtc>
    </passengersGroup>';
$req_Fare_InformativePricingWithoutPNR.=$request_soap_adult;
}
if($infant_config>0)
    { 
     $quantity=$quantity+1; 
  $infant_detail='<passengersGroup>
    <segmentRepetitionControl>
      <segmentControlDetails>
        <quantity>'.$quantity.'</quantity>
        <numberOfUnits>'.$infant_config.'</numberOfUnits>
      </segmentControlDetails>
    </segmentRepetitionControl>
    <travellersID>';
    for($infant=1;$infant<=$infant_config;$infant++)
      {
      $infant_detail.='<travellerDetails>
        <measurementValue>'.$infant.'</measurementValue>
      </travellerDetails>';
      }
   $infant_detail.='</travellersID>
      <discountPtc>
        <valueQualifier>INF</valueQualifier>
        <fareDetails>
          <qualifier>766</qualifier>
        </fareDetails>
      </discountPtc>
  </passengersGroup>';
  $req_Fare_InformativePricingWithoutPNR.=$infant_detail;
}
  if($child_config>0)
 { 
  $quantity=$quantity+1; 
   $child_loop_disconnect=$adult_config + $child_config; 
  $child_details='<passengersGroup>
    <segmentRepetitionControl>
      <segmentControlDetails>
        <quantity>'.$quantity.'</quantity>
        <numberOfUnits>'.$child_config.'</numberOfUnits>
      </segmentControlDetails>
    </segmentRepetitionControl>
    <travellersID>';
    for($child=$adult;$child<=$child_loop_disconnect;$child++)
    {
  $child_details.='<travellerDetails>
        <measurementValue>'.$child.'</measurementValue>
      </travellerDetails>';
    }
      $child_details.='
    </travellersID>
      <discountPtc>
        <valueQualifier>CH</valueQualifier>
      </discountPtc>
   </passengersGroup>';
  $req_Fare_InformativePricingWithoutPNR.=$child_details;
 }
$slice_flight=search_booking_itinerary_using_ref($pass_data); //booking segment
if(empty($slice_flight))
{
echo $err_flight_ref='<errorDetails>
<errorOrgin>FRNF</errorOrgin>
<errorText>Flight Reference Not Found</errorText>
</errorDetails>';
  exit;
}
//booking segment
//echo '<pre>';
//print_r($slice_flight);
//exit;
$itemNumber=1;
$dep_details=$slice_flight->departureFlights->flightDetails;

$segment='';
$flight_indicate=0;
foreach ($dep_details as $key => $depsegment) {
$departure_date=$depsegment->flightInformation->productDateTime->dateOfDeparture;
$fromlocation=$depsegment->flightInformation->location[0]->locationId;
$tolocation=$depsegment->flightInformation->location[1]->locationId;
$marketing=$depsegment->flightInformation->companyId->marketingCarrier;
$operating=$depsegment->flightInformation->companyId->operatingCarrier;
$flightno=$depsegment->flightInformation->flightOrtrainNumber;
$cabin=$depsegment->cabinProduct->rbd;
$flight_indicate=$flight_indicate+1;
$segment1='<segmentGroup>
    <segmentInformation>
      <flightDate>
        <departureDate>'.$departure_date.'</departureDate>
      </flightDate>
      <boardPointDetails>
        <trueLocationId>'.$fromlocation.'</trueLocationId>
      </boardPointDetails>
      <offpointDetails>
        <trueLocationId>'.$tolocation.'</trueLocationId>
      </offpointDetails>
      <companyDetails>
        <marketingCompany>'.$marketing.'</marketingCompany>
        <operatingCompany>'.$operating.'</operatingCompany>
      </companyDetails>
      <flightIdentification>
        <flightNumber>'.$flightno.'</flightNumber>
        <bookingClass>'.$cabin.'</bookingClass>
      </flightIdentification>
      <flightTypeDetails>
        <flightIndicator>1</flightIndicator>
      </flightTypeDetails>
      <itemNumber>'.$itemNumber.'</itemNumber>
    </segmentInformation>
  </segmentGroup>';
$itemNumber=$itemNumber+1;
$req_Fare_InformativePricingWithoutPNR.=$segment1; 
}

if(!empty($slice_flight->returnFlights->flightDetails))
{
$ret_details=$slice_flight->returnFlights->flightDetails;
$segment='';
$flight_indicate=0;
foreach ($ret_details as $key => $depsegment) {
$departure_date=$depsegment->flightInformation->productDateTime->dateOfDeparture;
$fromlocation=$depsegment->flightInformation->location[0]->locationId;
$tolocation=$depsegment->flightInformation->location[1]->locationId;
$marketing=$depsegment->flightInformation->companyId->marketingCarrier;
$operating=$depsegment->flightInformation->companyId->operatingCarrier;
$flightno=$depsegment->flightInformation->flightOrtrainNumber;
$cabin=$depsegment->cabinProduct->rbd;
$flight_indicate=$flight_indicate+1;
$segment2='<segmentGroup>
    <segmentInformation>
      <flightDate>
        <departureDate>'.$departure_date.'</departureDate>
      </flightDate>
      <boardPointDetails>
        <trueLocationId>'.$fromlocation.'</trueLocationId>
      </boardPointDetails>
      <offpointDetails>
        <trueLocationId>'.$tolocation.'</trueLocationId>
      </offpointDetails>
      <companyDetails>
        <marketingCompany>'.$marketing.'</marketingCompany>
        <operatingCompany>'.$operating.'</operatingCompany>
      </companyDetails>
      <flightIdentification>
        <flightNumber>'.$flightno.'</flightNumber>
        <bookingClass>'.$cabin.'</bookingClass>
      </flightIdentification>
      <flightTypeDetails>
        <flightIndicator>2</flightIndicator>
      </flightTypeDetails>
      <itemNumber>'.$itemNumber.'</itemNumber>
    </segmentInformation>
  </segmentGroup>';
$itemNumber=$itemNumber+1;
$req_Fare_InformativePricingWithoutPNR.=$segment2; 
}
}
$company=$marketing; 


$req_Fare_InformativePricingWithoutPNR.='<pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>FCO</pricingOptionKey>
    </pricingOptionKey>
    <currency>
      <firstCurrencyDetails>
        <currencyQualifier>FCO</currencyQualifier>
        <currencyIsoCode>USD</currencyIsoCode>
      </firstCurrencyDetails>
    </currency>
  </pricingOptionGroup>';


$req_Fare_InformativePricingWithoutPNR.='<pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>RP</pricingOptionKey>
    </pricingOptionKey>
  </pricingOptionGroup>
  <pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>RU</pricingOptionKey>
    </pricingOptionKey>
  </pricingOptionGroup>
  <pricingOptionGroup>
    <pricingOptionKey>
      <pricingOptionKey>VC</pricingOptionKey>
    </pricingOptionKey>
    <carrierInformation>
      <companyIdentification>
        <otherCompany>'.$company.'</otherCompany>
      </companyIdentification>
    </carrierInformation>
  </pricingOptionGroup>
</Fare_InformativePricingWithoutPNR>';
return $req_Fare_InformativePricingWithoutPNR;
}
?>
