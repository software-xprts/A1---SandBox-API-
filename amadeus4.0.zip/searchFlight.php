<?php
//error_reporting(0);
$json_data = file_get_contents('php://input');
$data      = json_decode($json_data, true);
if ($data['flightsuppliers'] != '') {
    $flight_sup = base64_decode($data['flightsuppliers']);
    $dflight    = json_decode($flight_sup, true);
    unset($data['flightsuppliers']);
    $json_data=json_encode($data);
    $username   = $dflight['username'];
    $password   = $dflight['password'];
    $officeid   = $dflight['officeid'];
    $code       = $dflight['code'];
    $endpoint   = $dflight['endpoint'];
    $version    = $dflight['version'];
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect Credentials');
    echo json_encode($errr);
    exit;
}
define('userName', $username);
define('password', $password);
define('office_id', $officeid);
define('AgentDutyCode', $code);
define('endpoint_uri', $endpoint);
define('master_pricer_mptbq', 'http://webservices.amadeus.com/' . $version);
define('queue_number_details','33');
include 'AmadeusService.php';
include 'apphead.php';
include 'appbody.php';

//debug($data);
//exit;
$_SESSION['src'] = date('Ymdhis-d-M-y');
$currencycode    = 'USD';
$directonly      = false;
if (empty($data)) {
    $triptype = strtolower($_REQUEST['tripType']);
    $origin        = $_REQUEST['origin'];
    $destination   = $_REQUEST['destination'];
    $departuredate = $_REQUEST['departureDate'];
    $returndate    = $_REQUEST['returnDate'];
    $adult_config  = $_REQUEST['adults'];
    $child_config  = $_REQUEST['childs'];
    $infant_config = $_REQUEST['infants'];
    $classtype     = $_REQUEST['classType'];
    $limit         = $_REQUEST['limit'];

    if (isset($_REQUEST['includeAirlines'])) {
        $incAirlines     = $_REQUEST['includeAirlines'];
        $includeAirlines = explode(',', $incAirlines);
        $count_included  = count($includeAirlines);
        if ($count_included > 3) {
                 $errr = array('status' => 'Fail', 'error' => 'Included options (Max three airlines allow by the gds');
        echo json_encode($errr);
        exit;
        
        }
    } else {
        $includeAirlines = '';
    }

    if (isset($_REQUEST['excludeAirlines'])) {
        $xclAirlines     = $_REQUEST['excludeAirlines'];
        $excludeAirlines = explode(',', $xclAirlines);
        $count_exclude   = count($excludeAirlines);
        if ($count_exclude > 3) {
            $errr = array('status' => 'Fail', 'error' => 'Excluded options (Max three airlines allow by the gds');
        echo json_encode($errr);
        exit;
        }
    } else {
        $excludeAirlines = '';
    }

    $limit = isset($limit) ? $limit : 200;
    if ($triptype == '' || $origin == '' || $destination == '' || $departuredate == '' || $returndate == '' || $adult_config == '' || $child_config == '' || $infant_config == '' || $classtype == '') {
        $errr = array('status' => 'Fail', 'error' => 'Incorrect User Input Request');
        echo json_encode($errr);
        exit;

    } else {
        $json_data = json_encode($_GET);
    }
} else {
    $triptype      = strtolower($data['tripType']);
    $adult_config  = $data['adults'];
    $child_config  = $data['childs'];
    $infant_config = $data['infants'];
    $classtype     = $data['classType'];
    $origin        = $data['origin'];
    $destination   = $data['destination'];
    $departuredate = $data['departureDate'];
    $returndate    = $data['returnDate'];
    $limit         = isset($data['limit']) ? $data['limit'] : 200;
    if (isset($data['includeAirlines'])) {
        $incAirlines     = $data['includeAirlines'];
        $includeAirlines = explode(',', $incAirlines);
        $count_included  = count($includeAirlines);
        if ($count_included > 3) {
            echo 'Included options (Max three airlines allow by the gds)';exit;
        }
    } else {
        $includeAirlines = '';
    }

    if (isset($data['excludeAirlines'])) {
        $xclAirlines     = $data['excludeAirlines'];
        $excludeAirlines = explode(',', $xclAirlines);
        $count_exclude   = count($excludeAirlines);
        if ($count_exclude > 3) {
            echo 'Included options (Max three airlines allow by the gds)';exit;
        }
    } else {
        $excludeAirlines = '';
    }
}

if ($triptype == 'roundtrip') {
    $triptype = 1;
} else if ($triptype == 'oneway') {
    $triptype = 0;
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorect Trip Type');
    echo json_encode($errr);
    exit;
}

//$classtype=cabin($classtype);
if ($classtype == 'unknown') {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect CabinClass');
    echo json_encode($errr);
    exit;
}
$val_pass = Check_pass_valid($adult_config, $child_config, $infant_config);
if ($val_pass) {
    $errr = array('status' => 'Fail', 'error' => $val_pass);
    echo json_encode($errr);
    exit;
}

$departure_date_arr = check_date($departuredate);
if ($departure_date_arr['error'] != '') {
    $errr = array('status' => 'Fail', 'error' => $departure_date_arr['error']);
    echo json_encode($errr);
    exit;
}
$depDt = $departure_date_arr['date'];
$retDt = '';
if ($triptype != 0) {
    $return_date_arr = check_date($returndate);
    if ($return_date_arr['error'] != '') {
        $errr = array('status' => 'Fail', 'error' => $return_date_arr['error']);
        echo json_encode($errr);
        exit;
    }
    $retDt     = ($return_date_arr['date'] != '' ? $return_date_arr['date'] : '');
    $dep_chek  = strtotime($departuredate);
    $ret_check = strtotime($returndate);
    if ($ret_check < $dep_chek) {
        $errr = array('status' => 'Fail', 'error' => 'Return Date is greater than departure date');
        echo json_encode($errr);
        exit;
    }
}
$folder_config = 'Xprts' . '/';
///echo $json_data;
//exit;
$search_id = search_id();
save_json_file($search_id, $folder_config . USERR_REQUEST, $json_data);

$pass_data = array('limit' => $limit, 'triptype' => $triptype, 'adult_config' => $adult_config, 'child_config' => $child_config, 'infant_config' => $infant_config, 'folder_config' => $folder_config, 'cabin' => $classtype);
$journey   = array('origin' => $origin, 'destination' => $destination, 'departuredate' => $depDt, 'returndate' => $retDt);
$flight_type='';
$body      = body_Fare_MasterPricerTravelBoardSearch($pass_data, $journey, $flight_type, $includeAirlines, $excludeAirlines);
//$body         = body_Fare_MasterPricerTravelBoardSearch($pass_data, $journey);
$actions      = array('action' => master_pricer_mptbq, 'to' => endpoint_uri);
$request_soap = context_less($body, $actions);
func_Fare_MasterPricerTravelBoardSearch($request_soap, $actions, $pass_data, $search_id);

function func_Fare_MasterPricerTravelBoardSearch($request_soap, $actions, $p_data, $search_id)
{
    extract($actions);
    extract($p_data);
    save_file_in_folder($search_id, $folder_config . FMPTBS_DIR_RQ, $request_soap);
    $headers = create_headers($action);
    $results = curl_executionWBSR($request_soap, $headers, $to);
    save_file_in_folder($search_id, $folder_config . FMPTBS_DIR_RS, $results);
    $data = X_XMLObject($results);
    if (empty($data->Body->Fare_MasterPricerTravelBoardSearchReply->errorMessage)) {
        $ref = get_response($search_id, $data, $triptype, $folder_config . LIST_DIR_RS, $adult_config, $child_config, $infant_config);
    } else {
        $error = $data;
        save_file_in_folder($search_id, $folder_config . ERR_DIR, $error->asXML());
        $errorcode = $data->Body->Fare_MasterPricerTravelBoardSearchReply->errorMessage->applicationError->applicationErrorDetail->error;
        $errortext = $data->Body->Fare_MasterPricerTravelBoardSearchReply->errorMessage->errorMessageText->description;
        // echo $err_Fare_InformativePricingWithoutPNR='<errorDetails>
        // <errorOrgin>FMPTBS</errorOrgin>
        // <errorCode>'.$errorcode.'</errorCode>
        // <errorText>'.$errortext.'</errorText>
        // </errorDetails>';

        $err_Fare_InformativePricingWithoutPNR      = array('status' => 'Fail', 'errorText' => $errortext, 'errorCode' => $errorcode);
        echo $err_Fare_InformativePricingWithoutPNR = json_encode($err_Fare_InformativePricingWithoutPNR);
        save_json_file($search_id, $folder_config . USERR_DIR, $err_Fare_InformativePricingWithoutPNR);
        exit;
    }
}
