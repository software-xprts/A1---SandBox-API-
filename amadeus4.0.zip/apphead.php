<?php
function get_header_info($data)
{
    $header_data['session_id']            = $data->Header->Session->SessionId;
    $SequenceNumber                       = $data->Header->Session->SequenceNumber;
    $header_data['SequenceNumber']        = $SequenceNumber + 1;
    $header_data['SecurityToken']         = $data->Header->Session->SecurityToken;
    $header_data['TransactionStatusCode'] = $data->Header->Session[0]['TransactionStatusCode'];
    return $header_data;
}
function context_full_header($actions, $sess_info)
{
    extract($actions);
    extract($sess_info);
    $header = '<soapenv:Header xmlns:add="http://www.w3.org/2005/08/addressing">
<add:MessageID>' . generateGuid() . '</add:MessageID>
<add:Action>' . $action . '</add:Action>
<add:To>' . $to . '</add:To>
<awsse:Session TransactionStatusCode="InSeries" xmlns:awsse="http://xml.amadeus.com/2010/06/Session_v3">
<awsse:SessionId>' . $session_id . '</awsse:SessionId>
<awsse:SequenceNumber>' . $SequenceNumber . '</awsse:SequenceNumber>
<awsse:SecurityToken>' . $SecurityToken . '</awsse:SecurityToken>
</awsse:Session>
</soapenv:Header>';
    return $header;
}

function context_less_header($actions, $start = false)
{
    $md = message_digest();
    extract($actions);
    $xml_rq = '
<soapenv:Header xmlns:add="http://www.w3.org/2005/08/addressing">
<add:MessageID>' . generateGuid() . '</add:MessageID>
<add:Action>' . $action . '</add:Action>
<add:To>' . $to . '</add:To>
<oas:Security xmlns:oas="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:oas1="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
<oas:UsernameToken oas1:Id="UsernameToken-1">
<oas:Username>' . $md['userName'] . '</oas:Username>
<oas:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">' . $md['nonce'] . '</oas:Nonce>
<oas:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">' . $md['passwordDigest'] . '</oas:Password>
<oas1:Created>' . $md['timeStamp'] . '</oas1:Created>
</oas:UsernameToken>
</oas:Security>
<AMA_SecurityHostedUser xmlns="http://xml.amadeus.com/2010/06/Security_v1">
<UserID AgentDutyCode="' . $md['AgentDutyCode'] . '" RequestorType="' . $md['RequestorType'] . '" PseudoCityCode="' . $md['PseudoCityCode'] . '" POS_Type="' . $md['POS_Type'] . '"/>
</AMA_SecurityHostedUser>';
    if (isset($start) and $start != '') {
        $xml_rq .= '<awsse:Session TransactionStatusCode="Start" xmlns:awsse="http://xml.amadeus.com/2010/06/Session_v3"/>';
    }
    $xml_rq .= '</soapenv:Header>';
    return $xml_rq;
}
function context_less($body, $actions, $start = false)
{
    extract($actions);
    if (!empty($session_info)) {
        $head = context_full_header($actions, $session_info);
    } else {
        $head = context_less_header($actions);
    }

    if ($start == false) {
        $xml_rq_cmn = 'xmlns:iat="http://www.iata.org/IATA/2007/00/IATA2010.1"';
    } else {
        $xml_rq_cmn = '';
    }

    $xml_rq = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sec="http://xml.amadeus.com/2010/06/Security_v1" xmlns:typ="http://xml.amadeus.com/2010/06/Types_v1"
    ' . $xml_rq_cmn . '
    xmlns:app="http://xml.amadeus.com/2010/06/AppMdw_CommonTypes_v3"
    xmlns:ses="http://xml.amadeus.com/2010/06/Session_v3">' . $head . '
<soapenv:Body>
' . $body . '
</soapenv:Body>
</soapenv:Envelope>';
    return $xml_rq;
}

//header end here

//validate flight start here

function display_user_err($data = array())
{
    extract($data);
    $err_ = '<errorDetails>
<errorOrgin>' . $errorOrgin . '</errorOrgin>
<errorCode>' . $errorCode . '</errorCode>
<errorText>' . $errorText . '</errorText>
</errorDetails>';
    return $err_;
}
function get_flight_number_booking_class($data_recommendation)
{
    $flightStatus = array();
    $check_       = $data_recommendation->Body->Air_SellFromRecommendationReply->message->messageFunctionDetails->messageFunction;
    $check_error  = $data_recommendation->Body->Air_SellFromRecommendationReply->errorAtMessageLevel;
    if ($check_ == '183' && empty($check_error)) {

        $first_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails[0];
        if (empty($first_trip)) {
            $first_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails;
        }
        $segment1 = $first_trip->segmentInformation;
        foreach ($segment1 as $key => $seg_status) {
            $flightNumber   = $seg_status->flightDetails->flightIdentification->flightNumber;
            $bookingClass   = $seg_status->flightDetails->flightIdentification->bookingClass;
            $status_code    = $seg_status->actionDetails->statusCode;
            $flightStatus[] = array('flightNumber' => $flightNumber, 'bookingClass' => $bookingClass, 'flightStatus' => $status_code);
        }
        $round_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails[1];
        if (empty($round_trip)) {
            $round_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails;
        }
        $segment2 = $round_trip->segmentInformation;
        foreach ($segment2 as $key => $seg_status) {

            $flightNumber   = $seg_status->flightDetails->flightIdentification->flightNumber;
            $bookingClass   = $seg_status->flightDetails->flightIdentification->bookingClass;
            $status_code    = $seg_status->actionDetails->statusCode;
            $flightStatus[] = array('flightNumber' => $flightNumber, 'bookingClass' => $bookingClass, 'flightStatus' => $status_code);
        }
    }

    if (!empty($flightStatus)) {
        return $flightStatus;
    }

}

function check_availability_A($res_Fare_InformativePricingWithoutPNR)
{
    $Fare_InformativePricingWithoutPNRReply = $res_Fare_InformativePricingWithoutPNR->Body->Fare_InformativePricingWithoutPNRReply->messageDetails->responseType;
    if ($Fare_InformativePricingWithoutPNRReply == 'A') {
        return true;
    } else {
        return false;
    }
}

function check_fare($res_Fare_InformativePricingWithoutPNR)
{

    $fare_array       = array();
    $Fare_Informative = $res_Fare_InformativePricingWithoutPNR->Body->Fare_InformativePricingWithoutPNRReply->mainGroup->pricingGroupLevelGroup;
    foreach ($Fare_Informative as $key => $price_info) {
        //debug($price_info);
        $count_pass = $price_info->numberOfPax->segmentControlDetails->numberOfUnits;
        $monetary   = $price_info->fareInfoGroup->fareAmount;
        foreach ($monetary as $key => $mon) {
            //$mon->otherMonetaryDetails->
            if ($mon->monetaryDetails->typeQualifier == 'B') {
                $mo_base=$mon->monetaryDetails;
                $basefare          = $mo_base->amount;
            }
            if ($mon->otherMonetaryDetails->typeQualifier == '712') {
                $mo=$mon->otherMonetaryDetails;
                $amt          = $mo->amount;
                $curr         = $mo->currency;
            }

        $fare_array[] = array('amt' => $amt,'base_fare' => $basefare, 'currency' => $curr, 'pass_count' => $count_pass);
        }
    }
    return $fare_array;
}




function calculate_total_fare_fipwpnr($fare)
{

    $total_amt = 0;
    $total_base_fare=0;
    foreach ($fare as $key => $f) {
        $amtunt    = (float) $f['amt']; //* $f['pass_count'];
        $total_amt = $total_amt + $amtunt;

        $base_fare    = (float) $f['base_fare']; //* $f['pass_count'];
        $total_base_fare = $total_base_fare + $base_fare;    

    }
    return array('total_fare'=>$total_amt,'total_base_fare'=>$total_base_fare);
}


function check_fare_old($res_Fare_InformativePricingWithoutPNR)
{
    
    $fare_array       = array();
    $Fare_Informative = $res_Fare_InformativePricingWithoutPNR->Body->Fare_InformativePricingWithoutPNRReply->mainGroup->pricingGroupLevelGroup;
    foreach ($Fare_Informative as $key => $price_info) {
        //debug($price_info);
        $count_pass = $price_info->numberOfPax->segmentControlDetails->numberOfUnits;
        $monetary   = $price_info->fareInfoGroup->fareAmount->otherMonetaryDetails;
        foreach ($monetary as $key => $mon) {
            if ($mon->typeQualifier == '712') {
                $amt          = $mon->amount;
                $curr         = $mon->currency;
                $fare_array[] = array('amt' => $amt, 'currency' => $curr, 'pass_count' => $count_pass);
            }
        }
    }
    return $fare_array;
}

function chk_status_ok_Air_SellFromRecommendation($data_recommendation)
{
    if (!empty($data_recommendation->Body->Fault)) {
        $faultcode   = $data_recommendation->Body->Fault->faultcode;
        $faultstring = $data_recommendation->Body->Fault->faultstring;
        $data        = array('errorOrgin' => 'ASFR', 'errorCode' => $faultcode, 'errorText' => $faultstring);
        echo $err    = display_user_err($data);
        exit;
    }
    $check_error = $data_recommendation->Body->Air_SellFromRecommendationReply->errorAtMessageLevel;
    if (!empty($check_error)) {
        return false;
    }
    $first_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails[0];
    if (empty($first_trip)) {
        $first_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails;
    }
    $segment1 = $first_trip->segmentInformation;
    foreach ($segment1 as $key => $seg_status) {
        $status_code = $seg_status->actionDetails->statusCode;
        if ($status_code == 'OK') {
            return true;
        } else {
            return false;
        }

    }
    //Round trip checking
    $round_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails[1];
    if (empty($round_trip)) {
        $round_trip = $data_recommendation->Body->Air_SellFromRecommendationReply->itineraryDetails;
    }
    $segment2 = $round_trip->segmentInformation;
    foreach ($segment2 as $key => $seg_status) {
        $status_code = $seg_status->actionDetails->statusCode;
        if ($status_code == 'OK') {
            return true;
        } else {
            return false;
        }

    }

}

function error_json_response($pass_data)
{
    extract($pass_data);
    $validate_response = '{
    "status": "Fail",
    "organizationId": "' . $organizationid . '",
    "searchID": "' . $search_id . '",
    "flightRefNumber": "' . $flightrefNumber . '",
    "adults": "' . $adult_config . '",
    "childs": "' . $child_config . '",
    "infants": "' . $infant_config . '",
    "error":"' . $errortext . '"}';
    return $validate_response;
}
//validate flight end here

//Book flight start here


function get_marketing_airline($flightListsearch_fare)
{
    $flight_for_airline = $flightListsearch_fare->departureFlights->flightDetails;
    foreach ($flight_for_airline as $key => $airlinec) {
        $marketingCar = $airlinec->flightInformation->companyId->marketingCarrier;
        break;
    }
    return $marketingCar;
}
function check_pnr($search_id,$res_PNR_AddMultiElements_commit, $website_folder_name)
{
    //check_pnr($searchid,$res_ssr_commit, $folder_config);
    if (!empty($res_PNR_AddMultiElements_commit->Body->PNR_Reply->generalErrorInfo)) {
        $xml_pnr          = '';
        $generalErrorInfo = $res_PNR_AddMultiElements_commit->Body->PNR_Reply->generalErrorInfo;

        save_file_in_folder($search_id,$website_folder_name . ERR_DIR, $generalErrorInfo->asXML());
        $errorCode = $generalErrorInfo->errorOrWarningCodeDetails->errorDetails->errorCode;
        $pnr_error = $generalErrorInfo->errorWarningDescription->freeText;
        foreach ($pnr_error as $key => $value) {
            $xml_pnr .= '<errorText>' . $value . '</errorText>';
        }
		echo $json_err='{"status": "Fail", "error": "Error on creating PNR"}';
		save_json_file($search_id,$website_folder_name.USERR_DIR,$json_err);
      //  save_file_in_folder($search_id,$website_folder_name . USERR_DIR, $errdete);
        return false;
    }

    $controlNumber          = $res_PNR_AddMultiElements_commit->Body->PNR_Reply->pnrHeader->reservationInfo->reservation->controlNumber;
    $inHouseIdentification1 = $res_PNR_AddMultiElements_commit->Body->PNR_Reply->sbrPOSDetails->sbrUserIdentificationOwn->originIdentification->inHouseIdentification1;
    if (isset($controlNumber)) {
        return array('controlNumber' => $controlNumber, 'inHouseIdentification1' => $inHouseIdentification1);
    } else {
        return false;
    }
}


function validate_passenger_data($passanger=array(),$journey_date,$pax_type='')
{
    foreach ($passanger as $key => $adult_data) {

    $fname   = $adult_data['firstName'];
    $surname = $adult_data['surname'];
    $dob=$adult_data['dob'];

    if($pax_type=='infant')
    validate_traveler_age($dob, $journey_date,$pax_type);
    else if($pax_type=='child')
    validate_traveler_age($dob, $journey_date,$pax_type);    
        
    $dob     = strtoupper(date('dMy', strtotime($dob)));
    $genders =(string)trim(strtoupper($adult_data['gender']));

    if($genders!='M' and $genders!='F')
    {
    $errr = array('status' => 'Fail', 'error' => 'Unknown Gender');
    echo json_encode($errr);exit;
    }
   
   if ($fname == '' || $surname == '' || $dob == '' || $genders == '') {
        $errr = array('status' => 'Fail', 'error' => 'Incorrect Passenger Data');
        echo json_encode($errr);
        exit; 
    }

    if($pax_type=='infant')
    {
        $genders=$genders.'I';

    }
 $array_adult[] = array(
            'fname'   => $adult_data['firstName'],
            'surname' => $adult_data['surname'],
            'dob'     => $dob,
            'gender'  => $genders,
        );
    
    }
   // print_r($array_adult);
   // exit;
    return $array_adult;

//$array_adult = array(array('fname' => 'Germain', 'surname' => 'Bolanos', 'dob' => '20SEP85', 'gender' => 'M'), array('fname' => 'Shreya', 'surname' => 'Ghoshal', 'dob' => '12SEP91', 'gender' => 'F'), array('fname' => 'Raushan', 'surname' => 'Kumar', 'dob' => '09JUL92', 'gender' => 'M'));
//debug($array_adult);
//exit;
  //  $array_child = array(array('fname' => 'Sanju', 'surname' => 'Samsung', 'dob' => '17SEP12', 'gender' => 'M'), array('fname' => 'Raushan', 'surname' => 'Mahnama', 'dob' => '18SEP13', 'gender' => 'M'));
   // $array_infant    = array(array('fname' => 'Divyansi', 'surname' => 'Kumari', 'dob' => '04SEP19', 'gender' => 'FI'), array('fname' => 'Priyanshu', 'surname' => 'Ranjan', 'dob' => '09SEP19', 'gender' => 'MI'));

}
function validate_traveler_age($passenger_dob, $journey_date, $passanger_type = '')
{
    $journey_date       = strtotime($journey_date); // or your date as well
    $your_date = strtotime($passenger_dob);
    $datediff  = $journey_date - $your_date;
    $day       = round($datediff / (60 * 60 * 24));
     if ($passanger_type == 'infant') {
        if ($day > 730) {

            $errr = array('status' => 'Fail', 'error' => 'Infant age is not valid');
            echo json_encode($errr);
            exit;
        }
    } else if($passanger_type == 'child') {
        if ($day > 4015) {

            $errr = array('status' => 'Fail', 'error' => 'Child age is not valid');
            echo json_encode($errr);
            exit;
        }

    }
    return true;
}
function validate_credit_card($payment_data)
{
$cardType         = $payment_data['type'];
$vendorCode       = $payment_data['vendorCode'];
$cardNumber       = $payment_data['cardNumber'];
$securityId       = $payment_data['securityId'];
$cardExpiry       = str_replace('/', '', $payment_data['expiryDate']);
$credit_card_info = array('cardType' => $cardType, 'securityId' => $securityId, 'vendorCode' => $vendorCode, 'cardNumber' => $cardNumber, 'cardExpiry' => $cardExpiry);
return $credit_card_info;  
//$credit_card_info = array('cardType' => 'CC', 'securityId' => '123', 'vendorCode' => 'VI', 'cardNumber' => '4000000000000002', 'cardExpiry' => '1222');
//exit;
}

function handle_soap_foalt($data,$web_service_no)
{
    $err=array();
    $faultcodes=$data->faultcode;
    $faultstring=$data->faultstring;
    $err['sequence_no']=$web_service_no;
    $err['status']='Fail';
    $err['faultcode']=$faultcodes;
    $err['faultstring']=$faultstring;
    echo json_encode($err);
    exit;
}

//book flight end here
?>