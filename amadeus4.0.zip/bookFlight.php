<?php
session_start();
//error_reporting(0);
$json_data = file_get_contents('php://input');
$data      = json_decode($json_data, true);
if ($data['flightsuppliers'] != '') {
    $flight_sup = base64_decode($data['flightsuppliers']);
    $dflight    = json_decode($flight_sup, true);
    unset($data['flightsuppliers']);
    $json_data=json_encode($data);
    $username   = $dflight['username'];
    $password   = $dflight['password'];
    $officeid   = $dflight['officeid'];
    $code       = $dflight['code'];
    $endpoint   = $dflight['endpoint'];
    $version    = $dflight['version'];
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect Credentials');
    echo json_encode($errr);
    exit;
}

define('userName', $username);
define('password', $password);
define('office_id', $officeid);
define('AgentDutyCode', $code);
define('endpoint_uri', $endpoint);
define('master_pricer_mptbq', 'http://webservices.amadeus.com/' . $version);
define('queue_number_details', '33');
include 'AmadeusService.php';
include 'apphead.php';
include 'appbody.php';
$folder_config = 'Xprts' . '/';
// M  - MALE
// F  - FEMALE
// MI - MALE INFANT
// FI - FEMALE INFANT
// U  - UNDISCLOSED GENDER

$organizationid  = $data['organizationId'];
$searchid        = $data['searchID'];
$flightRefNumber = $data['flightRefNumber'];

save_json_file($searchid, $folder_config . USERR_PNRREQUEST, $json_data);
$json_search_request = read_json_file($searchid, $folder_config . USERR_REQUEST);
$search_array        = json_decode($json_search_request, true);



$adult_config  = $search_array['adults'];
$child_config  = $search_array['childs'];
$infant_config = $search_array['infants'];

$pax             = $data['pax'];
$child_validate =0;
$infant_validate =0;
$adult_validate  = count($pax['adult']);
if (!empty($pax['child'])) {
$child_validate = count($pax['child']);
}
if (!empty($pax['infant'])) {
$infant_validate = count($pax['infant']);
}


if ($adult_config == $adult_validate && $child_config == $child_validate && $infant_validate == $infant_config) {
    $triptype      = strtolower($search_array['tripType']);
    $classtype     = $search_array['classType'];
    $origin        = $search_array['origin'];
    $destination   = $search_array['destination'];
    $departuredate = $search_array['departureDate'];
    $returndate    = $search_array['returnDate'];
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorrect Validation Request');
    echo json_encode($errr);
    exit;
}

if ($triptype == 'roundtrip') {
    $triptype = 1;
$check_dob=$returndate;
} else if ($triptype == 'oneway') {
    $triptype = 0;
    $check_dob=$departuredate;
} else {
    $errr = array('status' => 'Fail', 'error' => 'Incorect Trip Type');
    echo json_encode($errr);
    exit;
}
$array_child=array();
$array_infant=array();
$array_adult=validate_passenger_data($pax['adult'],$check_dob,'adult');
if (!empty($pax['child'])) {
       $array_child=validate_passenger_data($pax['child'],$check_dob,'child');
}
if (!empty($pax['infant'])) {
     $array_infant=validate_passenger_data($pax['infant'],$check_dob,'infant');
}

//debug($array_adult);
//exit;
//PNRACC_17_1_1A
///////////////////////////check Sessions valid/////////////////////////

$json_check_sessions=read_json_file($searchid,$folder_config.VALIDATE_PNRSESSION);
$sessions_array=json_decode($json_check_sessions,true);
$expiry=$sessions_array['expiry'];
$current_time=strtotime(date('Y-m-d H:i:s'));
if($current_time>=$expiry || $sessions_array['currentSearchId']=='lock')
{
    if($sessions_array['currentSearchId']=='lock')
        $errr = array('status' => 'Fail', 'error' => 'Session lock, Search Again');
            else
        $errr = array('status' => 'Fail', 'error' => 'Session expire');
    echo json_encode($errr);
    exit;
}
else
{
$sessions_array['currentSearchId']='lock';
save_json_file($searchid,$folder_config.VALIDATE_PNRSESSION,json_encode($sessions_array));
}
//////////////////////////end check Sessions valid////////////////////////////


$act_asfr                             = 'http://webservices.amadeus.com/ITAREQ_05_2_IA';
$act_sec_signout                      = 'http://webservices.amadeus.com/VLSSOQ_04_1_1A';
$action_PNR_AddMultiElements          = 'http://webservices.amadeus.com/PNRADD_17_1_1A';
$action_Fare_PricePNRWithBookingClass = 'http://webservices.amadeus.com/TPCBRQ_18_1_1A';
$action_Ticket_CreateTSTFromPricing   = 'http://webservices.amadeus.com/TAUTCQ_04_1_1A';
$action_FOP_CreateFormOfPayment       = 'http://webservices.amadeus.com/TFOPCQ_19_2_1A';
$action_Queue_PlacePNR                = 'http://webservices.amadeus.com/QUQPCQ_03_1_1A';

$pass_data = array('flightrefNumber' => $flightRefNumber, 'triptype' => $triptype, 'adult_config' => $adult_config, 'child_config' => $child_config, 'infant_config' => $infant_config, 'folder_config' => $folder_config, 'search_id' => $searchid);
$journey   = array('origin' => $origin, 'destination' => $destination, 'departuredate' => $departuredate, 'returndate' => $returndate);
//Add multielements start here

$foldername                     = $folder_config . AIRSFR_DIR_RS;
$res_Air_SellFromRecommendation = read_file_from_folder($foldername, $searchid);
$res_Air_SellFromRecommendation = X_XMLObject($res_Air_SellFromRecommendation);
$session_data                   = get_header_info($res_Air_SellFromRecommendation);
$b_addMulti                     = body_PNR_AddMultiElements($pass_data, $journey, $array_adult, $array_child, $array_infant);
$actions_addmulti               = array('action' => $action_PNR_AddMultiElements, 'to' => endpoint_uri, 'rq' => PNRAddMultiElements_DIR_RQ, 'rs' => PNRAddMultiElements_DIR_RS, 'start' => '1', 'session_info' => $session_data);
$rq_admultielement              = context_less($b_addMulti, $actions_addmulti);
$res_PNRAddMultiElements        = get_generic_response($rq_admultielement, $actions_addmulti, $pass_data);

if(!empty($res_PNRAddMultiElements->Body->Fault))
{
handle_soap_foalt($res_PNRAddMultiElements->Body->Fault,'2');
}



//debug($res_PNRAddMultiElements);
//exit;
//Fare_PricePNRWithBookingClass start here

$flightListsearch_fare             = search_booking_itinerary_using_ref($pass_data);
$mktCarrier                        = get_marketing_airline($flightListsearch_fare);
$b_farepricepnrbookingclass        = body_Fare_PricePNRWithBookingClass($mktCarrier);
$session_data['SequenceNumber']    = 3;
$actions_farepricepnrbookingclass  = array('action' => $action_Fare_PricePNRWithBookingClass, 'to' => endpoint_uri, 'rq' => Fare_PricePNRWithBookingClass_DIR_RQ, 'rs' => Fare_PricePNRWithBookingClass_DIR_RS, 'start' => '1', 'session_info' => $session_data);
$rq_Fare_PricePNRWithBookingClass  = context_less($b_farepricepnrbookingclass, $actions_farepricepnrbookingclass);
$res_Fare_PricePNRWithBookingClass = get_generic_response($rq_Fare_PricePNRWithBookingClass, $actions_farepricepnrbookingclass, $pass_data);
//debug($res_Fare_PricePNRWithBookingClass);
//tst start herer
//exit;
$b_tst                          = body_Ticket_CreateTSTFromPricing($pass_data);
$session_data['SequenceNumber'] = 4;
$actions_ttst                   = array('action' => $action_Ticket_CreateTSTFromPricing, 'to' => endpoint_uri, 'rq' => Ticket_CreateTSTFromPricing_DIR_RQ, 'rs' => Ticket_CreateTSTFromPricing_DIR_RS, 'start' => '1', 'session_info' => $session_data);
$rq_tst                         = context_less($b_tst, $actions_ttst);
$res_tst                        = get_generic_response($rq_tst, $actions_ttst, $pass_data);
//print_r($res_tst);

//need to pass passenger credit card details in body_FOP_CreateFormOfPayment
$credit_card_info=validate_credit_card($data['paymentInfo']);
//debug($credit_card_info);
$b_FOP_CreateFormOfPayment      = body_FOP_CreateFormOfPayment($credit_card_info);
$session_data['SequenceNumber'] = 5;
$actions_CreateFormOfPayment    = array('action' => $action_FOP_CreateFormOfPayment, 'to' => endpoint_uri, 'rq' => FOP_CreateFormOfPayment_DIR_RQ, 'rs' => FOP_CreateFormOfPayment_DIR_RS, 'start' => '1', 'session_info' => $session_data);
$rq_FOP_CreateFormOfPayment     = context_less($b_FOP_CreateFormOfPayment, $actions_CreateFormOfPayment);
$res_CreateFormOfPayment        = get_generic_response($rq_FOP_CreateFormOfPayment, $actions_CreateFormOfPayment, $pass_data);
//print_r($res_CreateFormOfPayment);

//ssr start here
$add_multi_folder               = $folder_config . PNRAddMultiElements_DIR_RS;
$res_PNR_AddMultiElements       = read_file_from_folder($add_multi_folder, $searchid);
$res_PNR_AddMultiElements       = X_XMLObject($res_PNR_AddMultiElements);
$PT_From_PNR_AddMultiElements   = $res_PNR_AddMultiElements->Body->PNR_Reply->travellerInfo;
$b_ssr                          = create_ssrb($PT_From_PNR_AddMultiElements, $array_adult, $array_child, $array_infant);
$session_data['SequenceNumber'] = 6;
$actions_SSR                    = array('action' => $action_PNR_AddMultiElements, 'to' => endpoint_uri, 'rq' => req_CommitPnr_DIR_RQ, 'rs' => res_CommitPnr_DIR_RS, 'start' => '1', 'session_info' => $session_data);
$rq_ssr                         = context_less($b_ssr, $actions_SSR);
$res_ssr_commit                 = get_generic_response($rq_ssr, $actions_SSR, $pass_data);
$pnr_element                    = check_pnr($searchid,$res_ssr_commit, $folder_config);

if (!empty($pnr_element['controlNumber'])) {
//Queue place pnr start here
    $Queue_PlacePNRB                = queu_place_pnrb($pnr_element);
    $session_data['SequenceNumber'] = 7;
    $actions_queuePlace             = array('action' => $action_Queue_PlacePNR, 'to' => endpoint_uri, 'rq' => Queue_PlacePNR_DIR_RQ, 'rs' => Queue_PlacePNR_DIR_RS, 'start' => '1', 'session_info' => $session_data);
    $rq_PlacePNR                    = context_less($Queue_PlacePNRB, $actions_queuePlace);
    $res_Queue_PlacePNR             = get_generic_response($rq_PlacePNR, $actions_queuePlace, $pass_data);
   // debug($res_Queue_PlacePNR);
 $pnr_contorls_number=$res_Queue_PlacePNR->Body->Queue_PlacePNRReply->recordLocator->reservation->controlNumber;
$data['PNR']=$pnr_contorls_number;
$pnr_user_response=array('bookingResponse'=>$data);

//$data['PNR']=json_encode(json_encode(($pnr_element['controlNumber']));
//$data['QueuePlacePNR']=$status;
$pnr_user_response['flight']=$flightListsearch_fare;
$pnr_user_response['searchRequest']=$search_array;
$pnr_user_response['status']='Success';
echo $pnr_success_response=json_encode($pnr_user_response);
save_json_file($searchid, $folder_config . USERR_PNRRESPONSE, $pnr_success_response);  
}
else
{
$sessions_array['currentSearchId']='unlock';
save_json_file($searchid,$folder_config.VALIDATE_PNRSESSION,json_encode($sessions_array));
}

$seqnum                         = $session_data['SequenceNumber'] + 1;
$session_data['SequenceNumber'] = $seqnum;
$body_Security_SignOut          = signout_body();
$Security_SignOut_A             = array('action' => $act_sec_signout, 'to' => endpoint_uri, 'rq' => S_SignOut_DIR_RQ, 'rs' => S_SignOut_DIR_RS, 'start' => '1', 'session_info' => $session_data);
$rq_Security_SignOut            = context_less($body_Security_SignOut, $Security_SignOut_A);
$res_Security_SignOut           = get_generic_response($rq_Security_SignOut, $Security_SignOut_A, $pass_data);
//debug($res_Security_SignOut);
exit;
?>