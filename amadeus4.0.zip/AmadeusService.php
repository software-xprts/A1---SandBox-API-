<?php 
date_default_timezone_set('Asia/Kolkata');
define('USERR_REQUEST','searchRequest');
//define('LIST_DIR_RS','flightList');
define('LIST_DIR_RS','searchResponse');
define('VALIDATE_REQUEST','validationRequest');
define('VALIDATE_RESPONSE','validationResponse');
define('VALIDATE_PNRSESSION','pnrSession');
define('USERR_PNRREQUEST','pnrUserRequest');
define('USERR_PNRRESPONSE','pnrUserResponse');

define('USERR_DIR','UserError');
define('ERR_DIR','Error');
define('FMPTBS_DIR_RQ','req_Fare_MasterPricerTravelBoardSearch');
define('FMPTBS_DIR_RS','res_Fare_MasterPricerTravelBoardSearch');

define('FIPWOP_DIR_RS','res_Fare_InformativePricingWithoutPNR');
define('FIPWOP_DIR_RQ','req_Fare_InformativePricingWithoutPNR');
define('AIRSFR_DIR_RQ','req_Air_SellFromRecommendation');
define('AIRSFR_DIR_RS','res_Air_SellFromRecommendation');
define('S_SignOut_DIR_RQ','req_Security_SignOut');
define('S_SignOut_DIR_RS','res_Security_SignOut');
define('FC_Rules_DIR_RQ','req_Fare_CheckRules');
define('FC_Rules_DIR_RS','res_Fare_CheckRules');
define('PNRAddMultiElements_DIR_RQ','req_PNR_AddMultiElements');
define('PNRAddMultiElements_DIR_RS','res_PNR_AddMultiElements');
define('Fare_PricePNRWithBookingClass_DIR_RQ','req_Fare_PricePNRWithBookingClass');
define('Fare_PricePNRWithBookingClass_DIR_RS','res_Fare_PricePNRWithBookingClass');
define('Ticket_CreateTSTFromPricing_DIR_RQ','req_Ticket_CreateTSTFromPricing');
define('Ticket_CreateTSTFromPricing_DIR_RS','res_Ticket_CreateTSTFromPricing');
define('FOP_CreateFormOfPayment_DIR_RQ','req_FOP_CreateFormOfPayment');
define('FOP_CreateFormOfPayment_DIR_RS','res_FOP_CreateFormOfPayment');
define('req_CommitPnr_DIR_RQ','req_CommitPnr');
define('res_CommitPnr_DIR_RS','res_CommitPnr');
define('Queue_PlacePNR_DIR_RQ','req_Queue_PlacePNR');
define('Queue_PlacePNR_DIR_RS','res_Queue_PlacePNR');
define('PNR_Retrieve_DIR_RQ','PNR_RetrieveRQ');
define('PNR_Retrieve_DIR_RS','PNR_RetrieveRS');
define('DocIssuance_IssueTicket_DIR_RQ','DocIssuance_IssueTicketRQ');
define('DocIssuance_IssueTicket_DIR_RS','DocIssuance_IssueTicketRS');
define('PNRCancle_DIR_RQ','PNR_CancelRQ');
define('PNRCancle_DIR_RS','PNR_CancelRS');

// define('userName', 'WSSXIIBE');
// define('password', 'sXiA3@pr1');
// define('office_id', 'YTOC421I9');
// define('AgentDutyCode', 'SU');
// define('endpoint_uri','https://nodeD1.test.webservices.amadeus.com/1ASIWIBESXI');
// define('master_pricer_mptbq','http://webservices.amadeus.com/FMPTBQ_17_4_1A');
//define('queue_number_details','33');
function message_digest()
{
    date_default_timezone_set("UTC");
    $t                     = microtime(true);
    $micro                 = sprintf("%03d", ($t - floor($t)) * 1000);
    $date                  = new DateTime(date('Y-m-d H:i:s.' . $micro));
    $timestamp             = $date->format("Y-m-d\TH:i:s:") . $micro . 'Z';
    $nonce                 = openssl_random_pseudo_bytes(16);
    $encodedNonce          = base64_encode($nonce);
    $passSHA               = base64_encode(sha1($nonce . $timestamp . sha1(password, true), true));
    $arr['nonce']          = $encodedNonce;
    $arr['passwordDigest'] = $passSHA;
    $arr['timeStamp']      = $timestamp;
    $arr['userName']       = userName;
    $arr['PseudoCityCode'] = office_id;
    $arr['AgentDutyCode']  = AgentDutyCode;
    $arr['POS_Type']       = '1';
    $arr['RequestorType']  = 'U';
    return $arr;
}

function save_json_file($search,$foldername,$data)
{
 $responseFile = fopen($foldername."/".$search.".json", "w") or die("File is not open!");
  fwrite($responseFile,$data);
  fclose($responseFile);
}


function read_json_file($search_id,$foldername)
{
 $file_path=$foldername.'/'.$search_id.'.json';
if(!file_exists($file_path))
{
  echo '{"status":"Fail","error":"Wrong search id!"}';exit;
}
else if(!filesize($file_path))
{
 echo '{"status":"Fail","error":"No itenary found!"}'; exit;
}
$myfile = fopen($file_path, "r") or die("Wrong search id!");
$data=fread($myfile,filesize($file_path));
fclose($myfile);
return $data;
}

function search_booking_itinerary_using_ref($search_data=array())
{
  extract($search_data);
  $data=read_file_from_folder($folder_config.LIST_DIR_RS,$search_id);
  $response_data=simplexml_load_string($data);
  foreach ($response_data as $key => $amadeusCustomResponse) {
    if($flightrefNumber==$amadeusCustomResponse->flightRefNumber)
    {
     return $slice_flight=$amadeusCustomResponse;  
    }
  }

}

function create_timestamp_fm($pass_data)
{
  extract($pass_data);
  $data='{DateTime:'. gmdate('Y-m-d H:i:s').'}';
  $resFile = fopen($folder_config."/timeStamp_".$search_id.".txt", "w") or die("Unable to open file!");
   fwrite($resFile,$data);
   fclose($resFile);  
}


function create_timestamp($session_data,$pass_data)
{
  extract($pass_data);
  if($session_data!='')
  {
  $path=$folder_config.AIRSFR_DIR_RQ;
  $data=read_file_from_folder($path,$search_id);
  $data=X_XMLObject($data);
  $timestamp_=$data->Header->Security->UsernameToken->Created;
  //date_default_timezone_set("Asia/Calcutta"); 
  $data='{TimeStamp: '.$timestamp_.',Session_ID: '.$session_data.',DateTime:'. gmdate('Y-m-d H:i:s').'}';
  $resFile = fopen($folder_config."/timeStamp_".$session_data.".txt", "w") or die("Unable to open file!");
   fwrite($resFile,$data);
   fclose($resFile);  
  }  
}



// function search_id(){
//   return $charId=md5(date('Ymdhis').microtime().mt_rand());
// }
function search_id(){
    $charId=md5(date('Ymdhis').microtime().mt_rand());
        $uuid =substr($charId, 10, 2)
            . substr($charId, 12, 4)
            . substr($charId, 20, 12)
            . 'd'.date('ymdhis');
        return $uuid;
}
function generateGuid()
    {
        $charId=md5(date('Ymdhis').microtime().mt_rand());
        $hyphen = chr(45); // "-"
        $uuid = substr($charId, 0, 8) . $hyphen
            . substr($charId, 8, 4) . $hyphen
            . substr($charId, 12, 4) . $hyphen
            . substr($charId, 16, 4) . $hyphen
            . substr($charId, 20, 12);
        return $uuid;
    }


//message_digest1();
function get_generic_response($request_soap,$soap_action=array(),$search_data=array()){
if(!empty($search_data) && !empty($soap_action))
{
  $search_id=$search_data['search_id'];
  $folder_config=$search_data['folder_config'];
  extract($soap_action);
  save_file_in_folder($search_id,$folder_config.$rq,$request_soap);
$headers=create_headers($action);
$results=curl_executionWBSR($request_soap,$headers,$to);
save_file_in_folder($search_id,$folder_config.$rs,$results);
$data=X_XMLObject($results);
return $data;
}
else 
return false;
}


function find_cabin_seatavailability($fareDetails)
{
 // debug($fareDetails);
  //exit;
$groupOfFares=$fareDetails->groupOfFares;
$bookingClassDetails=$fareDetails->majCabin->bookingClassDetails;
foreach ($groupOfFares as $key => $productIn) {
  $cabin=$productIn->productInformation->cabinProduct;
  $fareType=$productIn->productInformation->fareProductDetail->fareType;
$fareBasis=$productIn->productInformation->fareProductDetail->fareBasis;
$xml[]='<fareBasis>'.$fareBasis.'</fareBasis>
<fareType>'.$fareType.'</fareType>'.$cabin->asXML().$bookingClassDetails->asXML();
}
return $xml;
}
function elapse_flying_time($ind)
{
return $flying_time=$ind->flightProposal[1]->ref;
}


function get_fare_xml($recomend, $adult = '', $child = '', $infant = '')
{

   $total_amt           = $recomend->recPriceInfo->monetaryDetail[0]->amount;
//echo '<br>';
    $total_tax_amt       = $recomend->recPriceInfo->monetaryDetail[1]->amount;

//echo '<br>';
   $total_base_fare     =  (float)$total_amt - (float)$total_tax_amt;
//echo '<br>';
//exit;
    $paxFareProduct      = $recomend->paxFareProduct;
    $res_pax             = '<paxFareProduct>';
    $totalFareAmount_CH  = 0;
    $totalTaxAmount_CH   = 0;
    $totalFareAmount_INF = 0;
    $totalTaxAmount_INF  = 0;
//debug($paxFareProduct);
    foreach ($paxFareProduct as $pax) {
        $ptc = $pax->paxReference->ptc;
        if ($ptc == 'ADT') {
            $res_pax .= '<adults>';
            $totalFareAmount = $pax->paxFareDetail->totalFareAmount;
            $totalTaxAmount  = $pax->paxFareDetail->totalTaxAmount;

            $totalbaseFare = (float)$totalFareAmount - (float)$totalTaxAmount;

            $res_pax .= '<traveller>' . $adult . '</traveller>
<baseFarePerAdult>' . $totalbaseFare . '</baseFarePerAdult>
<taxPerAdult>' . $totalTaxAmount . '</taxPerAdult>';
            $res_pax .= '</adults>';
        }
        if ($ptc == 'CNN') {
            $res_pax .= '<childs>';
            $totalFareAmount_CH = $pax->paxFareDetail->totalFareAmount;
            $totalTaxAmount_CH  = $pax->paxFareDetail->totalTaxAmount;

            $totalbaseFare_CH = (float)$totalFareAmount_CH - (float)$totalTaxAmount_CH;

            $res_pax .= '<traveller>' . $child . '</traveller>
<baseFarePerChild>' . $totalbaseFare_CH . '</baseFarePerChild>
<taxPerChild>' . $totalTaxAmount_CH . '</taxPerChild>';
            $res_pax .= '</childs>';
        }
        if ($ptc == 'INF') {
            $res_pax .= '<infants>';
            $totalFareAmount_INF = $pax->paxFareDetail->totalFareAmount;
            $totalTaxAmount_INF  = $pax->paxFareDetail->totalTaxAmount;


            $totalbaseFare_INF= (float)$totalFareAmount_INF - (float)$totalTaxAmount_INF;
            

            $res_pax .= '<traveller>' . $infant . '</traveller>
<baseFarePerInfant>' . $totalbaseFare_INF . '</baseFarePerInfant>
<taxPerInfant>' . $totalTaxAmount_INF . '</taxPerInfant>';
            $res_pax .= '</infants>';
        }

    }
//$totalbaseFare=(float)$totalFareAmount + (float)$totalFareAmount_CH + (float)$totalFareAmount_INF;
    //$totaltax=(float)$totalTaxAmount + (float)$totalTaxAmount_CH + (float)$totalTaxAmount_INF;
    $res_pax .= '<totalbaseFare>' . $total_base_fare . '</totalbaseFare>
<totaltax>' . $total_tax_amt . '</totaltax>
<totalFare>' . $total_amt . '</totalFare>';
    $res_pax .= '</paxFareProduct>';
    return $res_pax;
}
function create_ref()
{
return $flightRefNumber=md5(uniqid(date('Ymdhis').microtime(),true)); 
}

function find_local_availability($specifc_records,$type,$refn)
{
   $segment_one=false;
   $segment_two=false;
   $array_a1='';
   $array_a2='';
   $a1='';
   $a2='';
   $r1='';
   $r2='';
foreach ($specifc_records as $key => $value) {
  //debug($value);
$reference_type=$value->specificRecItem->referenceType;
$reference_no=$value->specificRecItem->refNumber;
if($reference_type==$type && $refn==$reference_no)
{
$fareContext=$value->specificProductDetails->fareContextDetails;
   foreach ($fareContext as $key => $value) {
         $seg1=$value->requestedSegmentInfo->segRef;
          if($seg1==1)
          {
            $segment_one=true;
            $data1=$value->cnxContextDetails;
            foreach ($data1 as $key => $local1) {
              $array_a1.=$local1->fareCnxInfo->contextDetails->availabilityCnxType.',';
            }
          }
          if($seg1==2)
          {
            $segment_two=true;
            $data2=$value->cnxContextDetails;
            foreach ($data2 as $key => $local2) {
              $array_a2.=$local2->fareCnxInfo->contextDetails->availabilityCnxType.',';
            }
          }
      }
}
}
      if($segment_one)
      {
      $a1=rtrim($array_a1,',');
      $r1=explode(',',$a1);
      }
  
      if($segment_two)
      {
      $a2=rtrim($array_a2,',');
      $r2=explode(',',$a2);
      }
      $data=array('segd'=>$r1,'sega'=>$r2);
      return $data;
}



function fetch_avail_ref_context($referencingDetail) 
{
$refno_1='';
foreach ($referencingDetail as $value) {
  if($value->refQualifier=='A')
  {
    $refno_1='A,'.$value->refNumber;
    break;
  }
}
if(isset($refno_1))
{
  $refno_1=explode(',', $refno_1);
}
return $refno_1;
}

function get_response($searchID,$data,$triptype,$foldername,$adult,$child,$infant)
{
if(!empty($data->Body->Fault))
{
handle_soap_foalt($data->Body->Fault,'1');
}
$row=1;  
$res_mptb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
$res_mptb.='<FlightsInfo>';
$Fare_MasterPricerTravelBoardSearchReply=$data->Body->Fare_MasterPricerTravelBoardSearchReply;
$currency=$Fare_MasterPricerTravelBoardSearchReply->conversionRate->conversionRateDetail->currency;
if($triptype==1)
{
 $flight_index_zero=$Fare_MasterPricerTravelBoardSearchReply->flightIndex[0];
 $flight_index_one=$Fare_MasterPricerTravelBoardSearchReply->flightIndex[1];
}
else
{
$flight_index_zero=$Fare_MasterPricerTravelBoardSearchReply->flightIndex;
}
$recommendation=$Fare_MasterPricerTravelBoardSearchReply->recommendation;
foreach ($recommendation as $key => $recomend) {


$fare_MPTB=get_fare_xml($recomend,$adult,$child,$infant);
$fareDetails=$recomend->paxFareProduct->fareDetails[0];
$paxFareProduct1=$recomend->paxFareProduct;
if(!empty($recomend->paxFareProduct->fareDetails[0]))
{
$cabin_seat_array_xml_for_depart_flights=find_cabin_seatavailability($recomend->paxFareProduct->fareDetails[0]);
}
else
{
$cabin_seat_array_xml_for_depart_flights=find_cabin_seatavailability($recomend->paxFareProduct->fareDetails);
}


$availiability_cnx=false;
if(!empty($recomend->specificRecDetails)){
$availiability_cnx=true;
 }


$segmentFlightRef=$recomend->segmentFlightRef;
foreach($segmentFlightRef as $referencingDetail)
    {
 $depart_reference_no=$referencingDetail->referencingDetail[0]->refNumber - 1;
 if($depart_reference_no<0)
 $depart_reference_no=$referencingDetail[0]->refNumber - 1;
 $depart=$flight_index_zero->groupOfFlights[$depart_reference_no];
$data_availaibility='';
if(!empty($availiability_cnx))
{
$avl=fetch_avail_ref_context($referencingDetail); 
$qualifier=$avl[0];
$reference=$avl[1];
if($qualifier!='' && $reference!='')
$data_availaibility=find_local_availability($recomend->specificRecDetails,$qualifier,$reference);
//debug($data_availaibility);
}

$EFT=elapse_flying_time($depart->propFlightGrDetail);
$d_flightDetails=$depart->flightDetails;
$flightRefNumber = create_ref() . '_' . $row;
//$flightRefNumber = 'raushan' . '_' . $row;
$res_header='<CustomResponse><searchID>'.$searchID.'</searchID>
<flightRefNumber>'.$flightRefNumber.'</flightRefNumber><Currency>'.$currency.'</Currency>
<departureFlights><totalFlightDuration>'.$EFT.'</totalFlightDuration>';
$res_mptb.=$res_header;
$seat_avail_depart=0; 
foreach ($d_flightDetails as $dflightInfo) {
 $d_flight_info=$dflightInfo->flightInformation;
 $cabinxml=$cabin_seat_array_xml_for_depart_flights[$seat_avail_depart];
  $rq_departureFlights='<flightDetails>'.$d_flight_info->asXML().$cabinxml;
  if(!empty($data_availaibility['segd']))
  {
 $rq_departureFlights.='<flightTypeIndicator>'.$data_availaibility['segd'][$seat_avail_depart].'</flightTypeIndicator>';    
  }else {}
  $rq_departureFlights.='</flightDetails>';
 $seat_avail_depart=$seat_avail_depart+1;

$res_mptb.=$rq_departureFlights;
}
$res_mptb.='</departureFlights>';


if($triptype==1)
{
  $rq_arrivalFlights='';
  $cabin_seat_array_xml_for_return_flights=find_cabin_seatavailability($recomend->paxFareProduct->fareDetails[1]);
       $arrival_reference_no=$referencingDetail->referencingDetail[1]->refNumber - 1;
       if($arrival_reference_no<0)
       $arrival_reference_no=$referencingDetail[1]->refNumber - 1;
       $arriv=$flight_index_one->groupOfFlights[$arrival_reference_no]; 
       $EFT=elapse_flying_time($arriv->propFlightGrDetail);
    $res_mptb.='<returnFlights><totalFlightDuration>'.$EFT.'</totalFlightDuration>';
        $a_flightDetails=$arriv->flightDetails;
      $seat_avail_return=0;
      foreach ($a_flightDetails as $aflightInfo) {
       $aflightInfo=$aflightInfo->flightInformation;
       $cabinxml=$cabin_seat_array_xml_for_return_flights[$seat_avail_return];
       
        $rq_arrivalFlights='<flightDetails>'.$aflightInfo->asXML().$cabinxml;

          if(!empty($data_availaibility['sega']))
  {
$rq_arrivalFlights.='<flightTypeIndicator>'.$data_availaibility['sega'][$seat_avail_return].'</flightTypeIndicator>';    
  }
        $rq_arrivalFlights.='</flightDetails>';
        $seat_avail_return=$seat_avail_return+1;
      $res_mptb.=$rq_arrivalFlights;
      }

   $res_mptb.='</returnFlights>';   
}
$res_mptb.=$fare_MPTB.'</CustomResponse>';

if($row==1)
$flight_ref=$flightRefNumber;
$row=$row+1;
   }
 }
 $res_mptb.='</FlightsInfo>';

 save_file_in_folder($searchID,$foldername,$res_mptb);

 $res_mptb=simplexml_load_string($res_mptb);
 echo $res_mptb=json_encode($res_mptb);exit;
 //exit;
 //return $flight_ref;
}


function save_file_in_folder($search,$foldername,$data)
{
$url=$foldername."/".$search.".xml";
$doc = new DomDocument('1.0');
$doc->preserveWhiteSpace = false;
$doc->formatOutput = true;
$doc->loadXML($data);
$doc->save($url);
}

function save_error_in_folder($search,$foldername,$data)
{
$url=$foldername."/".$search.".xml";
$doc = new DomDocument('1.0');
$doc->preserveWhiteSpace = false;
$doc->formatOutput = true;
$doc->loadXML($data);
$doc->save($url);
// $responseFile = fopen($foldername."/".$search_id.".xml", "w") or die("File is not open!");
//  fwrite($responseFile,$data);
//  fclose($responseFile);
}

function read_file_from_folder($foldername,$search_id)
{
$file_path=$foldername.'/'.$search_id.'.xml';
$myfile = fopen($file_path, "r") or die("File is not Open!");
$data=fread($myfile,filesize($file_path));
fclose($myfile);
return $data;
}
// M (Economy Standard)
// W (Economy Premium)
// Y (Economy)
// C (Business)
// F (First)

function debug($data)
{
echo '<pre>';
print_r($data);
}
function cabin($CabinClass)
{
 $CabinClass=strtolower($CabinClass); 
 if($CabinClass=='business')
 {
  return 'C';
 }
 else if($CabinClass=='economy' || $CabinClass=='economy standard')
 {
  return 'M';
 }
 else if($CabinClass=='first')
 {
  return 'F';
 }
 else if($CabinClass=='economy premium')
 {
  return 'W';
 }
 else
 {
 return 'unknown';
 }
 
}
function Check_pass_valid($adult,$child,$infant)
{
        $err='';
        $total_passenger=$adult + $child + $infant;
        if($total_passenger<1)
        {
        $err='Invalid passenger';   
        }
        else if($adult<1)
        {
        $err='Invalid passenger';
        }
        else if($total_passenger > 9)
        {
        $err='Too Many Passangers';
        }
        else if($infant>$adult)
        {
        $err='Too Many Infants';
        }
        return $err;
}


function check_date($FromDate)
{
  $pattern = '/^([0-9]{2})-([0-9]{2})-([0-9]{4})$/';
    if (!preg_match($pattern, $FromDate))
    {
     return $err=array('date'=>'','error'=>'Date is not Correct Format','success'=>false);
    }
$FromDate_p=explode('-',$FromDate); 
$FromDate=$FromDate_p['2']."-".$FromDate_p['1']."-".$FromDate_p['0']; 
  if(checkdate($FromDate_p['1'],$FromDate_p['0'],$FromDate_p['2']))
  {
  $search_date=strtotime($FromDate);
  $check_361=date('Y-m-d',strtotime(' + 361 days'));
  if (($search_date > time() && $search_date<strtotime($check_361) )  || $FromDate== date('Y-m-d')) {
            $dta=date('dmy',$search_date);
         return $err=array('date'=>$dta,'error'=>'','success'=>true);
          }
          else {
         return $err=array('date'=>'','error'=>'Date Is Not Valid','success'=>false);
              }
  }
   return $err=array('date'=>'','error'=>'Date Is Not Correct Format','success'=>false);
}

function check_airport($dest_cod)
{
$pattern = '/^([A-Z]{3})$/';
    if (!preg_match($pattern, $dest_cod)) return false;
    return true;
}

function get_cabin_class($cabin_id) 
{

           if ($cabin_id=='C' || $cabin_id=='D' || $cabin_id=='I' || $cabin_id=='J'|| $cabin_id=='Z')
              {
              return 'Business';
              }
              else if ($cabin_id=='F' || $cabin_id=='A' || $cabin_id=='P' || $cabin_id=='R')
              {
              return 'First';
              }
              else if ($cabin_id=='M' || $cabin_id=='W' || $cabin_id=='Y')
              {
              return 'Economy';
              }
              else
              {
              return 'Un Known';
              }
}
function seat_left($flights_detail)
  {
   foreach ($flights_detail as  $flights) 
    {
    return $seat_left=$flights['NoOfSeatsLeft'];
    }
  }
 
function X_XMLObject($xml)
{
$results = preg_replace('/(<\s*)\w+:/','$1',$xml);   // removes <soap:
$results = preg_replace('/(<\/\s*)\w+:/','$1',$results); // removes </soap:
$data=simplexml_load_string($results);
return $data;
}
function create_headers($soap_action)
{
  $headers=array(
    'Content-Type: text/xml',
    'Accept-Charset: utf-8',
    'Accept: text/xml',
    'SOAPAction:'.$soap_action,
    'UserAgent: WebServices',
    'ContentLength: 3967');
 return $headers;
}
function curl_executionWBSR($request_soap,$headers,$AMD_wbs)
{
$curlConnection = curl_init();
curl_setopt($curlConnection, CURLOPT_HTTPHEADER,$headers);
curl_setopt($curlConnection, CURLOPT_URL, $AMD_wbs);
curl_setopt($curlConnection, CURLOPT_POST, TRUE);
curl_setopt($curlConnection, CURLOPT_POSTFIELDS,$request_soap);
curl_setopt($curlConnection, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($curlConnection, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curlConnection, CURLOPT_SSL_VERIFYPEER, FALSE);
$results = curl_exec($curlConnection);
return $results;
}

?>