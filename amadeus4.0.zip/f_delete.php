<?php 

function getFiles($directory) {
    
    if($dir = opendir($directory)) {
        $tmp = Array();
                while($file = readdir($dir)) {
            // Make sure the file exists
            if($file != "." && $file != ".." && $file[0] != '.') {
                // If it's a directiry, list all files within it
                if(is_dir($directory . "/" . $file)) {
                    $tmp2 = getFiles($directory . "/" . $file);
                    //print_r($tmp2);
                    if(is_array($tmp2)) {
                        $tmp = array_merge($tmp, $tmp2);
                    }
                } else {
                    array_push($tmp, $directory . "/" . $file);
                }
            }
        }

        // Finish off the function
        closedir($dir);
        return $tmp;
    }
}

$all_files=getFiles('Xprts');
echo '<pre>';
print_r($all_files); 

foreach ($all_files as $key => $value) {
    if(is_file($value))  
    {
     unlink($value);  
    }
}



exit;


$folder_path="Xprts"; 
$files = glob($folder_path.'/*');  
foreach($files as $file) { 
$amd_xml=glob($file.'/');
foreach ($amd_xml as  $xml) {
    if(is_file($xml))  
    {
        unlink($xml);  
    }
}
} 






//opendir() - Open directory handle
//readdir() - Read entry from directory handle
//closedir() - Close directory handle
//fnmatch() - Match filename against a pattern





$folder_path="Xprts\amadius_response_with_pnr"; 
$files = glob($folder_path.'/*');  
foreach($files as $file) { 
$amd_xml=glob($file.'/*.xml');
foreach ($amd_xml as  $xml) {
	if(is_file($xml))  
	{
       // unlink($xml);  
	}

}
} 
?>


